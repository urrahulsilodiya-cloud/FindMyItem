import React, { useState, useEffect, useMemo } from 'react';
import {
  SlidersHorizontal,
  ChevronRight,
  Search,
  Star,
  Check,
  X,
  ArrowUpDown,
  Layers,
} from 'lucide-react';
import { Category, Subcategory, Product, FilterState } from '../types';
import { getCategory } from '../services/categoryService';
import { getSubcategoriesForCategory } from '../services/categoryService';
import { searchAndFilterProducts } from '../services/productService';
import { ProductGrid } from '../components/product/ProductGrid';
import { getCategoryIcon } from '../utils/categoryIcons';
import { useCurrency } from '../context/CurrencyContext';

interface CategoryPageProps {
  categorySlug: string;
  onSelectProduct: (product: Product) => void;
  onWatchVideo: (product: Product) => void;
  onNavigateHome: () => void;
}

export const CategoryPage: React.FC<CategoryPageProps> = ({
  categorySlug,
  onSelectProduct,
  onWatchVideo,
  onNavigateHome,
}) => {
  const { formatPrice } = useCurrency();
  const [category, setCategory] = useState<Category | null>(null);
  const [subcategories, setSubcategories] = useState<Subcategory[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);

  // Filter States
  const [selectedSubcategory, setSelectedSubcategory] = useState<string | null>(null);
  const [categorySearch, setCategorySearch] = useState('');
  const [selectedBrands, setSelectedBrands] = useState<string[]>([]);
  const [minRating, setMinRating] = useState<number>(0);
  const [sortBy, setSortBy] = useState<FilterState['sortBy']>('popular');
  const [hasVideoReview, setHasVideoReview] = useState(false);
  const [mobileFilterOpen, setMobileFilterOpen] = useState(false);

  useEffect(() => {
    let mounted = true;
    async function loadCategoryData() {
      setLoading(true);
      const cat = await getCategory(categorySlug);
      if (!cat) {
        setLoading(false);
        return;
      }
      if (mounted) {
        setCategory(cat);
        const subs = await getSubcategoriesForCategory(cat.id);
        setSubcategories(subs);
      }
    }
    loadCategoryData();
    return () => {
      mounted = false;
    };
  }, [categorySlug]);

  // Load products based on filters
  useEffect(() => {
    let mounted = true;
    if (!category) return;

    async function loadFiltered() {
      setLoading(true);
      const res = await searchAndFilterProducts({
        categorySlug: category!.id,
        subcategorySlug: selectedSubcategory || undefined,
        searchQuery: categorySearch,
        brands: selectedBrands,
        minRating: minRating > 0 ? minRating : undefined,
        sortBy,
        hasVideoReview,
      });
      if (mounted) {
        setProducts(res);
        setLoading(false);
      }
    }
    loadFiltered();
    return () => {
      mounted = false;
    };
  }, [category, selectedSubcategory, categorySearch, selectedBrands, minRating, sortBy, hasVideoReview]);

  // Available brands in this category
  const availableBrands = useMemo(() => {
    const set = new Set<string>();
    products.forEach((p) => set.add(p.brand));
    return Array.from(set);
  }, [products]);

  const toggleBrand = (brand: string) => {
    setSelectedBrands((prev) =>
      prev.includes(brand) ? prev.filter((b) => b !== brand) : [...prev, brand]
    );
  };

  const clearAllFilters = () => {
    setSelectedSubcategory(null);
    setCategorySearch('');
    setSelectedBrands([]);
    setMinRating(0);
    setHasVideoReview(false);
    setSortBy('popular');
  };

  if (!loading && !category) {
    return (
      <div className="max-w-xl mx-auto text-center py-20 px-4">
        <h2 className="text-xl font-bold text-slate-800">Category Not Found</h2>
        <p className="text-sm text-slate-500 mt-2">The category you are looking for does not exist or has been hidden.</p>
        <button
          onClick={onNavigateHome}
          className="mt-6 px-6 py-2.5 bg-blue-600 text-white rounded-full text-sm font-semibold hover:bg-blue-700"
        >
          Return Home
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Breadcrumb */}
      <nav className="flex items-center gap-1.5 text-xs text-slate-500">
        <button onClick={onNavigateHome} className="hover:text-blue-600 transition-colors">
          Home
        </button>
        <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
        <span className="text-slate-400">Categories</span>
        <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
        <span className="font-semibold text-slate-800">{category?.name}</span>
      </nav>

      {/* Category Header */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/90 shadow-2xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="flex items-start gap-4">
            <div className="w-14 h-14 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center shrink-0 shadow-2xs">
              {category && getCategoryIcon(category.icon || category.slug, 'w-7 h-7')}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-2xl sm:text-3xl font-bold text-slate-900 font-['Space_Grotesk']">
                  {category?.name}
                </h1>
                <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-slate-100 text-slate-700">
                  {products.length} {products.length === 1 ? 'Product' : 'Products'}
                </span>
              </div>
              <p className="text-xs sm:text-sm text-slate-500 mt-1 max-w-2xl leading-relaxed">
                {category?.description}
              </p>
            </div>
          </div>

          {/* Quick in-category search */}
          <div className="relative w-full md:w-72">
            <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={categorySearch}
              onChange={(e) => setCategorySearch(e.target.value)}
              placeholder={`Search in ${category?.name || 'category'}...`}
              className="w-full pl-9 pr-8 py-2 bg-slate-50 focus:bg-white text-xs rounded-xl border border-slate-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-500/10 outline-none"
            />
            {categorySearch && (
              <button
                onClick={() => setCategorySearch('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>

        {/* Subcategories Pill Row */}
        {subcategories.length > 0 && (
          <div className="mt-6 pt-5 border-t border-slate-100">
            <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-thin">
              <span className="text-xs font-semibold text-slate-400 shrink-0">Subcategories:</span>
              <button
                onClick={() => setSelectedSubcategory(null)}
                className={`px-3 py-1 rounded-full text-xs font-semibold shrink-0 transition-colors ${
                  selectedSubcategory === null
                    ? 'bg-blue-600 text-white shadow-2xs'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                All
              </button>
              {subcategories.map((sub) => {
                const isSelected = selectedSubcategory === sub.id || selectedSubcategory === sub.slug;
                return (
                  <button
                    key={sub.id}
                    onClick={() => setSelectedSubcategory(isSelected ? null : sub.id)}
                    className={`px-3 py-1 rounded-full text-xs font-semibold shrink-0 transition-colors ${
                      isSelected
                        ? 'bg-blue-600 text-white shadow-2xs'
                        : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                    }`}
                  >
                    {sub.name}
                  </button>
                );
              })}
            </div>
          </div>
        )}
      </div>

      {/* Main Layout: Filters Sidebar + Products Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        
        {/* Filter Sidebar (Desktop) */}
        <div className="hidden lg:block space-y-6 bg-white p-5 rounded-2xl border border-slate-200 h-fit sticky top-24">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div className="flex items-center gap-2 font-bold text-slate-900 text-sm">
              <SlidersHorizontal className="w-4 h-4 text-blue-600" />
              <span>Filters</span>
            </div>
            {(selectedSubcategory || selectedBrands.length > 0 || minRating > 0 || hasVideoReview) && (
              <button
                onClick={clearAllFilters}
                className="text-xs text-blue-600 hover:underline font-semibold"
              >
                Reset All
              </button>
            )}
          </div>

          {/* Video Review Checkbox */}
          <div className="space-y-2">
            <label className="flex items-center gap-2.5 text-xs font-medium text-slate-700 cursor-pointer">
              <input
                type="checkbox"
                checked={hasVideoReview}
                onChange={(e) => setHasVideoReview(e.target.checked)}
                className="rounded border-slate-300 text-blue-600 focus:ring-blue-500 w-4 h-4"
              />
              <span>Has YouTube Video Review</span>
            </label>
          </div>

          {/* Rating Filter */}
          <div className="space-y-2 pt-4 border-t border-slate-100">
            <label className="text-xs font-bold text-slate-800 uppercase tracking-wider block">
              Minimum Rating
            </label>
            <div className="space-y-1.5">
              {[4.5, 4.0, 3.5].map((val) => (
                <button
                  key={val}
                  onClick={() => setMinRating(minRating === val ? 0 : val)}
                  className={`w-full text-left px-2.5 py-1.5 rounded-lg text-xs flex items-center justify-between transition-colors ${
                    minRating === val ? 'bg-blue-50 text-blue-700 font-bold' : 'hover:bg-slate-50 text-slate-600'
                  }`}
                >
                  <span className="flex items-center gap-1.5">
                    <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-500" />
                    <span>{val} & Above</span>
                  </span>
                  {minRating === val && <Check className="w-3.5 h-3.5 text-blue-600" />}
                </button>
              ))}
            </div>
          </div>

          {/* Brand Filter */}
          {availableBrands.length > 0 && (
            <div className="space-y-2 pt-4 border-t border-slate-100">
              <label className="text-xs font-bold text-slate-800 uppercase tracking-wider block">
                Brand
              </label>
              <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
                {availableBrands.map((brand) => (
                  <label
                    key={brand}
                    className="flex items-center gap-2 text-xs text-slate-600 hover:text-slate-900 cursor-pointer"
                  >
                    <input
                      type="checkbox"
                      checked={selectedBrands.includes(brand)}
                      onChange={() => toggleBrand(brand)}
                      className="rounded border-slate-300 text-blue-600 focus:ring-blue-500 w-3.5 h-3.5"
                    />
                    <span className="truncate">{brand}</span>
                  </label>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Products Column */}
        <div className="lg:col-span-3 space-y-5">
          {/* Sorting & Result Count Bar */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-3.5 rounded-2xl border border-slate-200">
            <span className="text-xs font-medium text-slate-500">
              Showing <strong className="text-slate-900">{products.length}</strong> items in{' '}
              <strong className="text-slate-900">{category?.name}</strong>
            </span>

            <div className="flex items-center gap-2">
              <ArrowUpDown className="w-3.5 h-3.5 text-slate-400" />
              <label htmlFor="category-sort" className="text-xs text-slate-500">Sort by:</label>
              <select
                id="category-sort"
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as FilterState['sortBy'])}
                className="text-xs font-semibold text-slate-800 bg-slate-50 border border-slate-200 rounded-lg py-1.5 px-2.5 focus:outline-none focus:ring-2 focus:ring-blue-500/10"
              >
                <option value="popular">Popular</option>
                <option value="latest">Latest</option>
                <option value="price-asc">Price: Low to High</option>
                <option value="price-desc">Price: High to Low</option>
                <option value="rating">Rating</option>
              </select>
            </div>
          </div>

          {/* Grid */}
          <ProductGrid
            products={products}
            isLoading={loading}
            onSelectProduct={onSelectProduct}
            onWatchVideo={onWatchVideo}
            emptyTitle={`No products found in ${category?.name}`}
            emptyMessage="Try clearing your filters or check other subcategories."
          />
        </div>
      </div>
    </div>
  );
};
