import React, { useState, useEffect } from 'react';
import { Video, Sparkles, Star, ExternalLink, Play, Layers } from 'lucide-react';
import { Product, Category } from '../types';
import { getProductsWithReviews } from '../services/productService';
import { getActiveCategories } from '../services/categoryService';
import { useCurrency } from '../context/CurrencyContext';

interface ReviewsPageProps {
  onSelectProduct: (product: Product) => void;
  onWatchVideo: (product: Product) => void;
  onNavigateHome: () => void;
}

export const ReviewsPage: React.FC<ReviewsPageProps> = ({
  onSelectProduct,
  onWatchVideo,
  onNavigateHome,
}) => {
  const { formatPrice } = useCurrency();
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [selectedCat, setSelectedCat] = useState<string | null>(null);
  const [activeInlineVideo, setActiveInlineVideo] = useState<Product | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([getProductsWithReviews(20), getActiveCategories()]).then(([prods, cats]) => {
      setProducts(prods);
      setCategories(cats);
      if (prods.length > 0) {
        setActiveInlineVideo(prods[0]);
      }
      setLoading(false);
    });
  }, []);

  const filtered = selectedCat
    ? products.filter((p) => p.categoryId === selectedCat)
    : products;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-10">
      
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-red-600 via-rose-600 to-slate-900 rounded-3xl p-6 sm:p-10 text-white relative overflow-hidden shadow-lg">
        <div className="relative z-10 max-w-2xl">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-white/20 backdrop-blur-md mb-3">
            <Video className="w-3.5 h-3.5 text-white" />
            <span>YouTube Review Showcase</span>
          </div>
          <h1 className="text-2xl sm:text-4xl font-extrabold tracking-tight font-['Space_Grotesk']">
            Watch Before You Buy
          </h1>
          <p className="text-xs sm:text-sm text-red-100 mt-2 leading-relaxed">
            See real tests, unboxings, ergonomics checks, and build quality verdicts from trusted creators before deciding.
          </p>
        </div>
      </div>

      {/* Featured Video Player Box */}
      {activeInlineVideo && (
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/90 shadow-2xs space-y-6">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <span className="text-xs font-bold text-red-600 uppercase tracking-wider">
                Featured Product Review
              </span>
              <h2 className="text-xl sm:text-2xl font-bold text-slate-900 font-['Space_Grotesk'] mt-0.5">
                {activeInlineVideo.youtubeTitle || `${activeInlineVideo.brand} ${activeInlineVideo.name}`}
              </h2>
            </div>
            <div className="flex items-center gap-3">
              <button
                onClick={() => onSelectProduct(activeInlineVideo)}
                className="px-4 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors"
              >
                View Full Specs
              </button>
              <a
                href={activeInlineVideo.buyUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-xl transition-colors flex items-center gap-1.5 shadow-2xs"
              >
                Buy on {activeInlineVideo.sellerName} <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>
          </div>

          <div className="relative aspect-video rounded-2xl overflow-hidden bg-black shadow-lg">
            {activeInlineVideo.youtubeVideoId ? (
              <iframe
                className="w-full h-full"
                src={`https://www.youtube-nocookie.com/embed/${activeInlineVideo.youtubeVideoId}?rel=0`}
                title={activeInlineVideo.youtubeTitle || activeInlineVideo.name}
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
              />
            ) : (
              <div className="w-full h-full flex items-center justify-center text-slate-400">
                <a
                  href={activeInlineVideo.youtubeUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="text-white hover:underline flex items-center gap-2"
                >
                  <Video className="w-5 h-5 text-red-500" /> Watch Review on YouTube
                </a>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Category Filter Pills */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-thin">
        <span className="text-xs font-semibold text-slate-400 shrink-0">Filter By Category:</span>
        <button
          onClick={() => setSelectedCat(null)}
          className={`px-3 py-1 rounded-full text-xs font-semibold shrink-0 transition-colors ${
            selectedCat === null
              ? 'bg-slate-900 text-white'
              : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
          }`}
        >
          All Video Reviews ({products.length})
        </button>
        {categories.map((cat) => (
          <button
            key={cat.id}
            onClick={() => setSelectedCat(cat.id === selectedCat ? null : cat.id)}
            className={`px-3 py-1 rounded-full text-xs font-semibold shrink-0 transition-colors ${
              selectedCat === cat.id
                ? 'bg-slate-900 text-white'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            {cat.name}
          </button>
        ))}
      </div>

      {/* Video Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {filtered.map((product) => (
          <div
            key={product.id}
            className={`bg-white rounded-2xl border overflow-hidden shadow-2xs hover:shadow-md transition-all flex flex-col justify-between ${
              activeInlineVideo?.id === product.id ? 'ring-2 ring-red-500 border-red-300' : 'border-slate-200'
            }`}
          >
            <div
              className="relative aspect-video bg-slate-900 cursor-pointer group"
              onClick={() => {
                setActiveInlineVideo(product);
                window.scrollTo({ top: 220, behavior: 'smooth' });
              }}
            >
              <img
                src={product.images[0]}
                alt={product.name}
                className="w-full h-full object-cover group-hover:opacity-80 transition-opacity"
              />
              <div className="absolute inset-0 flex items-center justify-center bg-black/30 group-hover:bg-black/40 transition-colors">
                <div className="w-12 h-12 rounded-full bg-red-600 text-white flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform">
                  <Play className="w-5 h-5 fill-white text-white ml-0.5" />
                </div>
              </div>
              <div className="absolute bottom-2.5 left-2.5 right-2.5 px-2 py-1 rounded bg-black/80 backdrop-blur-xs text-white text-[11px] font-medium line-clamp-1">
                {product.youtubeTitle || `Hands-on: ${product.name}`}
              </div>
            </div>

            <div className="p-4 flex-1 flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between text-xs mb-1">
                  <span className="font-semibold text-blue-600 uppercase tracking-wider text-[10px]">
                    {product.brand}
                  </span>
                  <div className="flex items-center gap-1 text-slate-700 bg-amber-50 px-2 py-0.5 rounded text-[11px]">
                    <Star className="w-3 h-3 fill-amber-400 text-amber-500" />
                    <span>{product.rating.toFixed(1)}</span>
                  </div>
                </div>
                <h3
                  onClick={() => onSelectProduct(product)}
                  className="font-bold text-slate-900 text-sm hover:text-blue-600 cursor-pointer line-clamp-2"
                >
                  {product.name}
                </h3>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between gap-2">
                <span className="text-sm font-bold text-slate-900">
                  {formatPrice(product.price)}
                </span>
                <div className="flex items-center gap-1.5">
                  <button
                    onClick={() => {
                      setActiveInlineVideo(product);
                      window.scrollTo({ top: 220, behavior: 'smooth' });
                    }}
                    className="px-2.5 py-1 text-xs font-semibold text-red-600 bg-red-50 hover:bg-red-100 rounded-lg transition-colors flex items-center gap-1"
                  >
                    <Play className="w-3 h-3 fill-current" /> Play
                  </button>
                  <button
                    onClick={() => onSelectProduct(product)}
                    className="px-2.5 py-1 text-xs font-semibold text-slate-600 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors"
                  >
                    Specs
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
