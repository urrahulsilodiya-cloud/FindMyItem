import React, { useState, useEffect } from 'react';
import { Product, Category } from '../types';
import { getActiveCategories } from '../services/categoryService';
import {
  getPublishedProducts,
  getTrendingInInterests,
  getProductsWithReviews,
  getLatestProducts,
} from '../services/productService';
import { HeroBanner } from '../components/home/HeroBanner';
import { ShopByCategory } from '../components/home/ShopByCategory';
import { PersonalizedDiscovery } from '../components/home/PersonalizedDiscovery';
import { TrendingProducts } from '../components/home/TrendingProducts';
import { DiscoverMore } from '../components/home/DiscoverMore';
import { TrustSection } from '../components/home/TrustSection';
import { InterestPicker } from '../components/home/InterestPicker';
import { X } from 'lucide-react';

interface HomePageProps {
  onSelectProduct: (product: Product) => void;
  onWatchVideo: (product: Product) => void;
  onNavigateCategory: (slug: string) => void;
  onNavigateReviews: () => void;
  forceShowPicker?: boolean;
}

const STORAGE_INTERESTS_KEY = 'fmi_user_interests';

export const HomePage: React.FC<HomePageProps> = ({
  onSelectProduct,
  onWatchVideo,
  onNavigateCategory,
  onNavigateReviews,
  forceShowPicker = false,
}) => {
  const [categories, setCategories] = useState<Category[]>([]);
  const [featuredProduct, setFeaturedProduct] = useState<Product | null>(null);
  const [trendingProducts, setTrendingProducts] = useState<Product[]>([]);
  const [videoProducts, setVideoProducts] = useState<Product[]>([]);
  const [latestProducts, setLatestProducts] = useState<Product[]>([]);
  const [featuredList, setFeaturedList] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // User interest selection state
  const [userInterests, setUserInterests] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_INTERESTS_KEY);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [isEditingInterestsModal, setIsEditingInterestsModal] = useState(forceShowPicker);

  useEffect(() => {
    if (forceShowPicker) {
      setIsEditingInterestsModal(true);
    }
  }, [forceShowPicker]);

  // Load initial store data
  useEffect(() => {
    let isMounted = true;
    async function loadData() {
      try {
        const [cats, allProducts, trending, videos, latest] = await Promise.all([
          getActiveCategories(),
          getPublishedProducts(),
          getTrendingInInterests([], 8),
          getProductsWithReviews(8),
          getLatestProducts(8),
        ]);

        if (!isMounted) return;

        setCategories(cats);
        setTrendingProducts(trending);
        setVideoProducts(videos);
        setLatestProducts(latest);

        // Featured products
        const featured = allProducts.filter((p) => p.featured);
        setFeaturedList(featured.length > 0 ? featured : allProducts.slice(0, 4));
        setFeaturedProduct(featured.length > 0 ? featured[0] : allProducts[0] || null);

        setIsLoading(false);
      } catch (err) {
        console.error('Failed to load home page data:', err);
        if (isMounted) setIsLoading(false);
      }
    }

    loadData();

    return () => {
      isMounted = false;
    };
  }, []);

  // Save interests handler
  const handleSaveInterests = (newInterests: string[]) => {
    setUserInterests(newInterests);
    try {
      localStorage.setItem(STORAGE_INTERESTS_KEY, JSON.stringify(newInterests));
    } catch (e) {
      console.error(e);
    }
  };

  const handleToggleInterest = (categoryId: string) => {
    const updated = userInterests.includes(categoryId)
      ? userInterests.filter((id) => id !== categoryId)
      : [...userInterests, categoryId];
    handleSaveInterests(updated);
  };

  const handleSelectAllInterests = () => {
    const allIds = categories.map((c) => c.id);
    handleSaveInterests(allIds);
  };

  const handleClearInterests = () => {
    handleSaveInterests([]);
  };

  const scrollToDiscovery = () => {
    const el = document.getElementById('personalized-discovery');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-12 sm:space-y-16">
      
      {/* 1. HERO SECTION */}
      <HeroBanner
        featuredProduct={featuredProduct}
        onSelectProduct={onSelectProduct}
        onWatchVideo={onWatchVideo}
        onExploreClick={scrollToDiscovery}
        onNavigateCategory={onNavigateCategory}
      />

      {/* 2. SHOP BY CATEGORY */}
      <ShopByCategory
        categories={categories}
        onNavigateCategory={onNavigateCategory}
      />

      {/* 3. PERSONALIZED PRODUCT DISCOVERY ("Find Products You'll Love") */}
      <PersonalizedDiscovery
        categories={categories}
        userInterests={userInterests}
        onToggleInterest={handleToggleInterest}
        onSelectAllInterests={handleSelectAllInterests}
        onClearInterests={handleClearInterests}
        onNavigateCategory={onNavigateCategory}
        onSelectProduct={onSelectProduct}
        onWatchVideo={onWatchVideo}
      />

      {/* 4. TRENDING PRODUCTS */}
      <TrendingProducts
        products={trendingProducts}
        categories={categories}
        onSelectProduct={onSelectProduct}
        onWatchVideo={onWatchVideo}
        onNavigateCategory={onNavigateCategory}
      />

      {/* 5. FEATURED / DISCOVER MORE */}
      <DiscoverMore
        videoProducts={videoProducts}
        latestProducts={latestProducts}
        featuredProducts={featuredList}
        onSelectProduct={onSelectProduct}
        onWatchVideo={onWatchVideo}
        onNavigateReviews={onNavigateReviews}
      />

      {/* 6. TRUST / WEBSITE PURPOSE & AFFILIATE DISCLOSURE */}
      <TrustSection />

      {/* Dedicated Interest Setup Modal if triggered from profile menu */}
      {isEditingInterestsModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="relative bg-white rounded-3xl w-full max-w-4xl shadow-2xl overflow-hidden my-8">
            <button
              onClick={() => setIsEditingInterestsModal(false)}
              className="absolute top-4 right-4 p-2 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-500 hover:text-slate-900 transition-colors z-10"
              aria-label="Close dialog"
            >
              <X className="w-5 h-5" />
            </button>
            <div className="max-h-[85vh] overflow-y-auto p-4 sm:p-6">
              <InterestPicker
                initialSelected={userInterests}
                onComplete={(selected) => {
                  handleSaveInterests(selected);
                  setIsEditingInterestsModal(false);
                }}
                onSkip={() => setIsEditingInterestsModal(false)}
              />
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
