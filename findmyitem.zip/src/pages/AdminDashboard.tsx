import React, { useState, useEffect } from 'react';
import {
  ShieldCheck,
  Package,
  Layers,
  Settings,
  Plus,
  Edit2,
  Trash2,
  Eye,
  Check,
  X,
  RefreshCw,
  Video,
  DollarSign,
  ExternalLink,
  ChevronRight,
  AlertTriangle,
  Upload,
} from 'lucide-react';
import { Product, Category, Subcategory, SiteSettings } from '../types';
import {
  getProducts,
  saveProduct,
  deleteProduct,
  resetToInitialData,
  getSettings,
  saveSettings,
} from '../services/storageService';
import { getAllCategories, saveCategory, deleteCategory } from '../services/categoryService';
import { getAllSubcategories, saveSubcategory, deleteSubcategory } from '../services/categoryService';
import { useToast } from '../context/ToastContext';
import { useAuth } from '../context/AuthContext';

interface AdminDashboardProps {
  onNavigateHome: () => void;
  onPreviewProduct: (product: Product) => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  onNavigateHome,
  onPreviewProduct,
}) => {
  const { isAdmin } = useAuth();
  const { showToast } = useToast();

  const [activeTab, setActiveTab] = useState<'overview' | 'products' | 'categories' | 'subcategories' | 'settings'>('overview');
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [subcategories, setSubcategories] = useState<Subcategory[]>([]);
  const [settings, setSettings] = useState<SiteSettings | null>(null);
  const [loading, setLoading] = useState(true);

  // Editing Modals / Forms
  const [editingProduct, setEditingProduct] = useState<Partial<Product> | null>(null);
  const [editingCategory, setEditingCategory] = useState<Partial<Category> | null>(null);
  const [editingSubcategory, setEditingSubcategory] = useState<Partial<Subcategory> | null>(null);

  // Helpers for array inputs in product form
  const [newImageInput, setNewImageInput] = useState('');
  const [newProInput, setNewProInput] = useState('');
  const [newConInput, setNewConInput] = useState('');
  const [newSpecLabel, setNewSpecLabel] = useState('');
  const [newSpecValue, setNewSpecValue] = useState('');

  const loadAll = async () => {
    setLoading(true);
    const [p, c, s, set] = await Promise.all([
      getProducts(),
      getAllCategories(),
      getAllSubcategories(),
      getSettings(),
    ]);
    setProducts(p);
    setCategories(c);
    setSubcategories(s);
    setSettings(set);
    setLoading(false);
  };

  useEffect(() => {
    loadAll();
  }, []);

  // --- Handlers: Product CRUD ---
  const handleSaveProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingProduct?.name || !editingProduct?.categoryId) {
      showToast('Name and Category are required', 'error');
      return;
    }

    // Auto extract YouTube Video ID if a full URL is provided
    let ytId = editingProduct.youtubeVideoId || '';
    if (editingProduct.youtubeUrl) {
      const match = editingProduct.youtubeUrl.match(/(?:youtu\.be\/|youtube\.com\/(?:embed\/|v\/|watch\?v=|watch\?.+&v=))([\w-]{11})/);
      if (match && match[1]) {
        ytId = match[1];
      }
    }

    const itemToSave: Product = {
      id: editingProduct.id || `prod-${Date.now()}`,
      name: editingProduct.name,
      slug: editingProduct.slug || editingProduct.name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)+/g, ''),
      brand: editingProduct.brand || 'Generic',
      categoryId: editingProduct.categoryId,
      subcategoryId: editingProduct.subcategoryId || '',
      price: Number(editingProduct.price) || 0,
      originalPrice: editingProduct.originalPrice ? Number(editingProduct.originalPrice) : undefined,
      discount: editingProduct.discount ? Number(editingProduct.discount) : undefined,
      currency: editingProduct.currency || 'USD',
      rating: Number(editingProduct.rating) || 5,
      reviewCount: Number(editingProduct.reviewCount) || 1,
      shortDescription: editingProduct.shortDescription || '',
      description: editingProduct.description || '',
      specifications: editingProduct.specifications || [],
      howToUse: editingProduct.howToUse || '',
      pros: editingProduct.pros || [],
      cons: editingProduct.cons || [],
      images: editingProduct.images && editingProduct.images.length > 0
        ? editingProduct.images
        : ['https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=800&q=80'],
      youtubeUrl: editingProduct.youtubeUrl || '',
      youtubeVideoId: ytId,
      youtubeTitle: editingProduct.youtubeTitle || '',
      youtubeDescription: editingProduct.youtubeDescription || '',
      buyUrl: editingProduct.buyUrl || 'https://amazon.com',
      sellerName: editingProduct.sellerName || 'Amazon Global',
      featured: Boolean(editingProduct.featured),
      published: editingProduct.published !== undefined ? editingProduct.published : true,
      tags: editingProduct.tags || [],
      createdAt: editingProduct.createdAt || new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    await saveProduct(itemToSave);
    showToast(`Product "${itemToSave.name}" saved successfully`, 'success');
    setEditingProduct(null);
    loadAll();
  };

  const handleDeleteProduct = async (id: string, name: string) => {
    if (window.confirm(`Are you sure you want to delete "${name}"?`)) {
      await deleteProduct(id);
      showToast(`Product deleted`, 'info');
      loadAll();
    }
  };

  // --- Handlers: Category CRUD ---
  const handleSaveCategory = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingCategory?.name) return;

    const catToSave: Category = {
      id: editingCategory.id || `cat-${editingCategory.name.toLowerCase().replace(/[^a-z0-9]+/g, '-')}`,
      name: editingCategory.name,
      slug: editingCategory.slug || editingCategory.name.toLowerCase().replace(/[^a-z0-9]+/g, '-'),
      description: editingCategory.description || '',
      icon: editingCategory.icon || 'Sparkles',
      displayOrder: Number(editingCategory.displayOrder) || categories.length + 1,
      isActive: editingCategory.isActive !== undefined ? editingCategory.isActive : true,
    };

    await saveCategory(catToSave);
    showToast(`Category "${catToSave.name}" saved`, 'success');
    setEditingCategory(null);
    loadAll();
  };

  const handleDeleteCategory = async (id: string, name: string) => {
    if (window.confirm(`Delete category "${name}"?`)) {
      await deleteCategory(id);
      showToast(`Category removed`, 'info');
      loadAll();
    }
  };

  // --- Handlers: Subcategory CRUD ---
  const handleSaveSubcategory = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingSubcategory?.name || !editingSubcategory?.parentCategoryId) {
      showToast('Name and Parent Category required', 'error');
      return;
    }

    const subToSave: Subcategory = {
      id: editingSubcategory.id || `sub-${editingSubcategory.name.toLowerCase().replace(/[^a-z0-9]+/g, '-')}`,
      name: editingSubcategory.name,
      slug: editingSubcategory.slug || editingSubcategory.name.toLowerCase().replace(/[^a-z0-9]+/g, '-'),
      parentCategoryId: editingSubcategory.parentCategoryId,
      description: editingSubcategory.description || '',
      displayOrder: Number(editingSubcategory.displayOrder) || 1,
      isActive: editingSubcategory.isActive !== undefined ? editingSubcategory.isActive : true,
    };

    await saveSubcategory(subToSave);
    showToast(`Subcategory "${subToSave.name}" saved`, 'success');
    setEditingSubcategory(null);
    loadAll();
  };

  const handleDeleteSubcategory = async (id: string, name: string) => {
    if (window.confirm(`Delete subcategory "${name}"?`)) {
      await deleteSubcategory(id);
      showToast('Subcategory removed', 'info');
      loadAll();
    }
  };

  // --- Reset to seed ---
  const handleResetData = async () => {
    if (window.confirm('Reset all categories, subcategories, and products to initial database seed data? This will overwrite manual changes.')) {
      await resetToInitialData();
      showToast('Database reset to verified seed data', 'success');
      loadAll();
    }
  };

  // --- Save Site Settings ---
  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!settings) return;
    await saveSettings(settings);
    showToast('Platform settings updated', 'success');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Top Header */}
      <div className="bg-slate-900 text-white rounded-3xl p-6 sm:p-8 flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-xl">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-blue-600 flex items-center justify-center text-white shadow-md shadow-blue-500/30">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-2xl font-bold font-['Space_Grotesk'] tracking-tight">
                FindMyItem Admin Console
              </h1>
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-blue-500/20 text-blue-300 border border-blue-400/30">
                Database Connected
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              Live CRUD management for products, categories, subcategories, video reviews & platform disclosure.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={handleResetData}
            className="px-3.5 py-2 rounded-xl text-xs font-semibold text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 transition-colors flex items-center gap-1.5"
            title="Reset database to default seed state"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Reset to Seed Data</span>
          </button>
          <button
            onClick={onNavigateHome}
            className="px-4 py-2 rounded-xl text-xs font-semibold text-white bg-blue-600 hover:bg-blue-500 transition-colors"
          >
            Exit to Website
          </button>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 overflow-x-auto pb-2">
        <button
          onClick={() => setActiveTab('overview')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-colors ${
            activeTab === 'overview' ? 'bg-blue-600 text-white' : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          Dashboard Overview
        </button>
        <button
          onClick={() => setActiveTab('products')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-colors flex items-center gap-1.5 ${
            activeTab === 'products' ? 'bg-blue-600 text-white' : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <Package className="w-4 h-4" />
          Products ({products.length})
        </button>
        <button
          onClick={() => setActiveTab('categories')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-colors flex items-center gap-1.5 ${
            activeTab === 'categories' ? 'bg-blue-600 text-white' : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <Layers className="w-4 h-4" />
          Categories ({categories.length})
        </button>
        <button
          onClick={() => setActiveTab('subcategories')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-colors ${
            activeTab === 'subcategories' ? 'bg-blue-600 text-white' : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          Subcategories ({subcategories.length})
        </button>
        <button
          onClick={() => setActiveTab('settings')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-colors flex items-center gap-1.5 ${
            activeTab === 'settings' ? 'bg-blue-600 text-white' : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <Settings className="w-4 h-4" />
          Site Settings
        </button>
      </div>

      {/* TAB 1: OVERVIEW METRICS */}
      {activeTab === 'overview' && (
        <div className="space-y-8">
          <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-white p-5 rounded-2xl border border-slate-200">
              <span className="text-xs font-bold text-slate-400 uppercase">Total Products</span>
              <div className="text-3xl font-extrabold text-slate-900 mt-2 font-['Space_Grotesk']">
                {products.length}
              </div>
              <span className="text-xs text-emerald-600 font-semibold mt-1 block">Live in Catalog</span>
            </div>
            <div className="bg-white p-5 rounded-2xl border border-slate-200">
              <span className="text-xs font-bold text-slate-400 uppercase">Categories</span>
              <div className="text-3xl font-extrabold text-slate-900 mt-2 font-['Space_Grotesk']">
                {categories.length}
              </div>
              <span className="text-xs text-blue-600 font-semibold mt-1 block">Interest Channels</span>
            </div>
            <div className="bg-white p-5 rounded-2xl border border-slate-200">
              <span className="text-xs font-bold text-slate-400 uppercase">Subcategories</span>
              <div className="text-3xl font-extrabold text-slate-900 mt-2 font-['Space_Grotesk']">
                {subcategories.length}
              </div>
              <span className="text-xs text-indigo-600 font-semibold mt-1 block">Faceted Filters</span>
            </div>
            <div className="bg-white p-5 rounded-2xl border border-slate-200">
              <span className="text-xs font-bold text-slate-400 uppercase">YouTube Reviews</span>
              <div className="text-3xl font-extrabold text-slate-900 mt-2 font-['Space_Grotesk']">
                {products.filter((p) => p.youtubeVideoId || p.youtubeUrl).length}
              </div>
              <span className="text-xs text-red-600 font-semibold mt-1 block">Video Integrations</span>
            </div>
          </div>

          {/* Quick Actions Card */}
          <div className="bg-white rounded-2xl border border-slate-200 p-6">
            <h3 className="font-bold text-slate-900 text-base mb-3 font-['Space_Grotesk']">
              Quick Admin Actions
            </h3>
            <div className="flex flex-wrap gap-3">
              <button
                onClick={() => {
                  setEditingProduct({
                    name: '',
                    brand: '',
                    categoryId: categories[0]?.id || '',
                    price: 99.99,
                    rating: 4.8,
                    reviewCount: 150,
                    featured: true,
                    images: ['https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=800&q=80'],
                    specifications: [{ label: 'Warranty', value: '1 Year Manufacturer' }],
                    pros: ['High build quality', 'Reliable performance'],
                    cons: ['Premium price point'],
                    sellerName: 'Amazon',
                    buyUrl: 'https://amazon.com',
                  });
                  setActiveTab('products');
                }}
                className="px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold flex items-center gap-1.5 shadow-sm"
              >
                <Plus className="w-4 h-4" /> Add New Product
              </button>
              <button
                onClick={() => {
                  setEditingCategory({
                    name: '',
                    slug: '',
                    description: '',
                    icon: 'Sparkles',
                    displayOrder: categories.length + 1,
                  });
                  setActiveTab('categories');
                }}
                className="px-4 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold flex items-center gap-1.5"
              >
                <Plus className="w-4 h-4" /> Add New Category
              </button>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: PRODUCTS MANAGEMENT */}
      {activeTab === 'products' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-bold text-slate-900 font-['Space_Grotesk']">
              Products Database ({products.length})
            </h2>
            <button
              onClick={() => {
                setEditingProduct({
                  name: '',
                  brand: '',
                  categoryId: categories[0]?.id || '',
                  price: 99,
                  rating: 5,
                  reviewCount: 50,
                  featured: false,
                  images: ['https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=800&q=80'],
                  specifications: [{ label: 'Material', value: 'High Grade' }],
                  pros: ['Great design'],
                  cons: ['None reported'],
                  sellerName: 'Official Store',
                  buyUrl: 'https://amazon.com',
                });
              }}
              className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold flex items-center gap-1.5"
            >
              <Plus className="w-4 h-4" /> Add Product
            </button>
          </div>

          {/* Product Edit / Create Modal Form */}
          {editingProduct && (
            <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
              <div className="bg-white rounded-3xl max-w-3xl w-full max-h-[90vh] overflow-y-auto p-6 sm:p-8 shadow-2xl border border-slate-200 space-y-6">
                <div className="flex items-center justify-between pb-4 border-b border-slate-100">
                  <h3 className="text-xl font-bold text-slate-900 font-['Space_Grotesk']">
                    {editingProduct.id ? 'Edit Product' : 'Add New Product'}
                  </h3>
                  <button
                    onClick={() => setEditingProduct(null)}
                    className="p-2 text-slate-400 hover:text-slate-700 rounded-full"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                <form onSubmit={handleSaveProduct} className="space-y-5">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="text-xs font-bold text-slate-700 block mb-1">Product Name *</label>
                      <input
                        type="text"
                        required
                        value={editingProduct.name || ''}
                        onChange={(e) => setEditingProduct({ ...editingProduct, name: e.target.value })}
                        className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs outline-none focus:border-blue-500"
                        placeholder="e.g. Sony WH-1000XM5"
                      />
                    </div>
                    <div>
                      <label className="text-xs font-bold text-slate-700 block mb-1">Brand *</label>
                      <input
                        type="text"
                        required
                        value={editingProduct.brand || ''}
                        onChange={(e) => setEditingProduct({ ...editingProduct, brand: e.target.value })}
                        className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs outline-none focus:border-blue-500"
                        placeholder="e.g. Sony"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div>
                      <label className="text-xs font-bold text-slate-700 block mb-1">Category *</label>
                      <select
                        required
                        value={editingProduct.categoryId || ''}
                        onChange={(e) => setEditingProduct({ ...editingProduct, categoryId: e.target.value })}
                        className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs outline-none"
                      >
                        {categories.map((c) => (
                          <option key={c.id} value={c.id}>
                            {c.name}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="text-xs font-bold text-slate-700 block mb-1">Subcategory</label>
                      <select
                        value={editingProduct.subcategoryId || ''}
                        onChange={(e) => setEditingProduct({ ...editingProduct, subcategoryId: e.target.value })}
                        className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs outline-none"
                      >
                        <option value="">None / General</option>
                        {subcategories
                          .filter((s) => s.parentCategoryId === editingProduct.categoryId)
                          .map((s) => (
                            <option key={s.id} value={s.id}>
                              {s.name}
                            </option>
                          ))}
                      </select>
                    </div>

                    <div>
                      <label className="text-xs font-bold text-slate-700 block mb-1">Price (USD) *</label>
                      <input
                        type="number"
                        step="0.01"
                        required
                        value={editingProduct.price ?? ''}
                        onChange={(e) => setEditingProduct({ ...editingProduct, price: parseFloat(e.target.value) })}
                        className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs outline-none"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div>
                      <label className="text-xs font-bold text-slate-700 block mb-1">Original Price (USD)</label>
                      <input
                        type="number"
                        step="0.01"
                        value={editingProduct.originalPrice ?? ''}
                        onChange={(e) => setEditingProduct({ ...editingProduct, originalPrice: parseFloat(e.target.value) })}
                        className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs outline-none"
                        placeholder="Optional"
                      />
                    </div>
                    <div>
                      <label className="text-xs font-bold text-slate-700 block mb-1">Discount %</label>
                      <input
                        type="number"
                        value={editingProduct.discount ?? ''}
                        onChange={(e) => setEditingProduct({ ...editingProduct, discount: parseInt(e.target.value) })}
                        className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs outline-none"
                        placeholder="e.g. 15"
                      />
                    </div>
                    <div>
                      <label className="text-xs font-bold text-slate-700 block mb-1">Rating (1-5)</label>
                      <input
                        type="number"
                        step="0.1"
                        min="1"
                        max="5"
                        value={editingProduct.rating ?? 4.8}
                        onChange={(e) => setEditingProduct({ ...editingProduct, rating: parseFloat(e.target.value) })}
                        className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs outline-none"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-xs font-bold text-slate-700 block mb-1">Short Description</label>
                    <input
                      type="text"
                      value={editingProduct.shortDescription || ''}
                      onChange={(e) => setEditingProduct({ ...editingProduct, shortDescription: e.target.value })}
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs outline-none"
                      placeholder="Brief one-line overview"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-bold text-slate-700 block mb-1">Detailed Description</label>
                    <textarea
                      rows={3}
                      value={editingProduct.description || ''}
                      onChange={(e) => setEditingProduct({ ...editingProduct, description: e.target.value })}
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs outline-none"
                      placeholder="Full product review, ergonomics, materials, durability, and verdict"
                    />
                  </div>

                  {/* YouTube Section */}
                  <div className="p-4 rounded-2xl bg-red-50/50 border border-red-100 space-y-3">
                    <div className="flex items-center gap-2 text-red-700 text-xs font-bold">
                      <Video className="w-4 h-4" />
                      <span>YouTube Review Integration</span>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="text-[11px] font-semibold text-slate-700 block mb-1">YouTube URL</label>
                        <input
                          type="text"
                          value={editingProduct.youtubeUrl || ''}
                          onChange={(e) => setEditingProduct({ ...editingProduct, youtubeUrl: e.target.value })}
                          className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs outline-none"
                          placeholder="https://www.youtube.com/watch?v=..."
                        />
                      </div>
                      <div>
                        <label className="text-[11px] font-semibold text-slate-700 block mb-1">Video Title</label>
                        <input
                          type="text"
                          value={editingProduct.youtubeTitle || ''}
                          onChange={(e) => setEditingProduct({ ...editingProduct, youtubeTitle: e.target.value })}
                          className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs outline-none"
                          placeholder="e.g. Sony WH-1000XM5: The Real Truth!"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Seller / Buy Link Section */}
                  <div className="p-4 rounded-2xl bg-blue-50/50 border border-blue-100 space-y-3">
                    <div className="flex items-center gap-2 text-blue-700 text-xs font-bold">
                      <ExternalLink className="w-4 h-4" />
                      <span>External Seller & Buy Link</span>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="text-[11px] font-semibold text-slate-700 block mb-1">Seller Name</label>
                        <input
                          type="text"
                          value={editingProduct.sellerName || ''}
                          onChange={(e) => setEditingProduct({ ...editingProduct, sellerName: e.target.value })}
                          className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs outline-none"
                          placeholder="e.g. Amazon, BestBuy, Nike"
                        />
                      </div>
                      <div>
                        <label className="text-[11px] font-semibold text-slate-700 block mb-1">Buy URL (External Store)</label>
                        <input
                          type="text"
                          value={editingProduct.buyUrl || ''}
                          onChange={(e) => setEditingProduct({ ...editingProduct, buyUrl: e.target.value })}
                          className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs outline-none"
                          placeholder="https://..."
                        />
                      </div>
                    </div>
                  </div>

                  {/* Featured & Active checkboxes */}
                  <div className="flex items-center gap-6 pt-2">
                    <label className="flex items-center gap-2 text-xs font-semibold text-slate-700 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={Boolean(editingProduct.featured)}
                        onChange={(e) => setEditingProduct({ ...editingProduct, featured: e.target.checked })}
                        className="rounded border-slate-300 text-blue-600 focus:ring-blue-500 w-4 h-4"
                      />
                      <span>Featured on Homepage</span>
                    </label>

                    <label className="flex items-center gap-2 text-xs font-semibold text-slate-700 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={editingProduct.published !== false}
                        onChange={(e) => setEditingProduct({ ...editingProduct, published: e.target.checked })}
                        className="rounded border-slate-300 text-blue-600 focus:ring-blue-500 w-4 h-4"
                      />
                      <span>Active / Published</span>
                    </label>
                  </div>

                  {/* Actions */}
                  <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-100">
                    <button
                      type="button"
                      onClick={() => setEditingProduct(null)}
                      className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="px-6 py-2.5 rounded-xl text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 shadow-md"
                    >
                      Save Product
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}

          {/* Products List Table */}
          <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-2xs">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-500 uppercase tracking-wider font-semibold border-b border-slate-200">
                  <tr>
                    <th className="p-3.5">Product</th>
                    <th className="p-3.5">Category</th>
                    <th className="p-3.5">Price</th>
                    <th className="p-3.5">Rating</th>
                    <th className="p-3.5">Video</th>
                    <th className="p-3.5">Status</th>
                    <th className="p-3.5 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {products.map((p) => (
                    <tr key={p.id} className="hover:bg-slate-50/70 transition-colors">
                      <td className="p-3.5 flex items-center gap-3">
                        <img
                          src={p.images[0]}
                          alt={p.name}
                          className="w-10 h-10 rounded-lg object-cover bg-slate-100 shrink-0"
                        />
                        <div className="min-w-0">
                          <div className="font-bold text-slate-900 truncate max-w-xs">{p.name}</div>
                          <div className="text-[11px] text-slate-400">{p.brand}</div>
                        </div>
                      </td>
                      <td className="p-3.5 text-slate-600 font-medium">
                        {categories.find((c) => c.id === p.categoryId)?.name || p.categoryId}
                      </td>
                      <td className="p-3.5 font-bold text-slate-900">${p.price}</td>
                      <td className="p-3.5 text-slate-700">★ {p.rating}</td>
                      <td className="p-3.5">
                        {p.youtubeVideoId ? (
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-red-100 text-red-700 flex items-center gap-1 w-fit">
                            <Video className="w-3 h-3" /> Yes
                          </span>
                        ) : (
                          <span className="text-slate-400">None</span>
                        )}
                      </td>
                      <td className="p-3.5">
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                            p.published ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-100 text-slate-500'
                          }`}
                        >
                          {p.published ? 'Active' : 'Draft'}
                        </span>
                      </td>
                      <td className="p-3.5 text-right space-x-2">
                        <button
                          onClick={() => onPreviewProduct(p)}
                          className="p-1.5 rounded-lg text-slate-500 hover:text-blue-600 hover:bg-slate-100"
                          title="Preview Product"
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => setEditingProduct(p)}
                          className="p-1.5 rounded-lg text-slate-500 hover:text-amber-600 hover:bg-slate-100"
                          title="Edit"
                        >
                          <Edit2 className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleDeleteProduct(p.id, p.name)}
                          className="p-1.5 rounded-lg text-slate-500 hover:text-rose-600 hover:bg-slate-100"
                          title="Delete"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: CATEGORIES MANAGEMENT */}
      {activeTab === 'categories' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-bold text-slate-900 font-['Space_Grotesk']">
              Categories ({categories.length})
            </h2>
            <button
              onClick={() => {
                setEditingCategory({
                  name: '',
                  slug: '',
                  description: '',
                  icon: 'Sparkles',
                  displayOrder: categories.length + 1,
                  isActive: true,
                });
              }}
              className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold flex items-center gap-1.5"
            >
              <Plus className="w-4 h-4" /> Add Category
            </button>
          </div>

          {editingCategory && (
            <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-4">
              <h3 className="font-bold text-slate-900 text-sm">
                {editingCategory.id ? 'Edit Category' : 'New Category'}
              </h3>
              <form onSubmit={handleSaveCategory} className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="text-xs font-semibold text-slate-700 block mb-1">Category Name *</label>
                  <input
                    type="text"
                    required
                    value={editingCategory.name || ''}
                    onChange={(e) => setEditingCategory({ ...editingCategory, name: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs outline-none"
                    placeholder="e.g. Photography"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-700 block mb-1">Icon Key</label>
                  <input
                    type="text"
                    value={editingCategory.icon || ''}
                    onChange={(e) => setEditingCategory({ ...editingCategory, icon: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs outline-none"
                    placeholder="e.g. Camera, Headphones, Shirt"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-700 block mb-1">Description</label>
                  <input
                    type="text"
                    value={editingCategory.description || ''}
                    onChange={(e) => setEditingCategory({ ...editingCategory, description: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs outline-none"
                    placeholder="Brief description"
                  />
                </div>
                <div className="sm:col-span-3 flex justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => setEditingCategory(null)}
                    className="px-4 py-2 text-xs text-slate-600"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 bg-blue-600 text-white rounded-xl text-xs font-bold"
                  >
                    Save Category
                  </button>
                </div>
              </form>
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {categories.map((c) => (
              <div
                key={c.id}
                className="bg-white p-4 rounded-2xl border border-slate-200 flex items-center justify-between"
              >
                <div>
                  <div className="font-bold text-slate-900 text-sm">{c.name}</div>
                  <div className="text-xs text-slate-400">{c.description || 'No description'}</div>
                </div>
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => setEditingCategory(c)}
                    className="p-1.5 text-slate-400 hover:text-amber-600"
                  >
                    <Edit2 className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => handleDeleteCategory(c.id, c.name)}
                    className="p-1.5 text-slate-400 hover:text-rose-600"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 4: SUBCATEGORIES MANAGEMENT */}
      {activeTab === 'subcategories' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-bold text-slate-900 font-['Space_Grotesk']">
              Subcategories ({subcategories.length})
            </h2>
            <button
              onClick={() => {
                setEditingSubcategory({
                  name: '',
                  parentCategoryId: categories[0]?.id || '',
                  description: '',
                  displayOrder: 1,
                  isActive: true,
                });
              }}
              className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold flex items-center gap-1.5"
            >
              <Plus className="w-4 h-4" /> Add Subcategory
            </button>
          </div>

          {editingSubcategory && (
            <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-4">
              <h3 className="font-bold text-slate-900 text-sm">
                {editingSubcategory.id ? 'Edit Subcategory' : 'New Subcategory'}
              </h3>
              <form onSubmit={handleSaveSubcategory} className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="text-xs font-semibold text-slate-700 block mb-1">Name *</label>
                  <input
                    type="text"
                    required
                    value={editingSubcategory.name || ''}
                    onChange={(e) => setEditingSubcategory({ ...editingSubcategory, name: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs outline-none"
                    placeholder="e.g. Wireless Earbuds"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-700 block mb-1">Parent Category *</label>
                  <select
                    required
                    value={editingSubcategory.parentCategoryId || ''}
                    onChange={(e) => setEditingSubcategory({ ...editingSubcategory, parentCategoryId: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs outline-none"
                  >
                    {categories.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-700 block mb-1">Description</label>
                  <input
                    type="text"
                    value={editingSubcategory.description || ''}
                    onChange={(e) => setEditingSubcategory({ ...editingSubcategory, description: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs outline-none"
                  />
                </div>
                <div className="sm:col-span-3 flex justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => setEditingSubcategory(null)}
                    className="px-4 py-2 text-xs text-slate-600"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 bg-blue-600 text-white rounded-xl text-xs font-bold"
                  >
                    Save Subcategory
                  </button>
                </div>
              </form>
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {subcategories.map((s) => (
              <div
                key={s.id}
                className="bg-white p-4 rounded-2xl border border-slate-200 flex items-center justify-between"
              >
                <div>
                  <div className="font-bold text-slate-900 text-sm">{s.name}</div>
                  <div className="text-[11px] text-blue-600 font-medium">
                    in {categories.find((c) => c.id === s.parentCategoryId)?.name || s.parentCategoryId}
                  </div>
                </div>
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => setEditingSubcategory(s)}
                    className="p-1.5 text-slate-400 hover:text-amber-600"
                  >
                    <Edit2 className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => handleDeleteSubcategory(s.id, s.name)}
                    className="p-1.5 text-slate-400 hover:text-rose-600"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 5: SITE SETTINGS */}
      {activeTab === 'settings' && settings && (
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 max-w-2xl">
          <h2 className="text-lg font-bold text-slate-900 font-['Space_Grotesk'] mb-4">
            Global Platform Settings & Transparency
          </h2>
          <form onSubmit={handleSaveSettings} className="space-y-4">
            <div>
              <label className="text-xs font-semibold text-slate-700 block mb-1">Platform Name</label>
              <input
                type="text"
                value={settings.websiteName}
                onChange={(e) => setSettings({ ...settings, websiteName: e.target.value })}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs outline-none"
              />
            </div>
            <div>
              <label className="text-xs font-semibold text-slate-700 block mb-1">Tagline</label>
              <input
                type="text"
                value={settings.tagline}
                onChange={(e) => setSettings({ ...settings, tagline: e.target.value })}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs outline-none"
              />
            </div>
            <div>
              <label className="text-xs font-semibold text-slate-700 block mb-1">
                Mandatory Affiliate & Marketplace Legal Disclosure
              </label>
              <textarea
                rows={4}
                value={settings.footerDisclosure}
                onChange={(e) => setSettings({ ...settings, footerDisclosure: e.target.value })}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs outline-none"
              />
            </div>
            <div>
              <label className="text-xs font-semibold text-slate-700 block mb-1">Contact Email</label>
              <input
                type="email"
                value={settings.contactEmail}
                onChange={(e) => setSettings({ ...settings, contactEmail: e.target.value })}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs outline-none"
              />
            </div>
            <button
              type="submit"
              className="px-6 py-2.5 rounded-xl bg-blue-600 text-white text-xs font-bold hover:bg-blue-700 shadow-md"
            >
              Save Settings
            </button>
          </form>
        </div>
      )}
    </div>
  );
};
