import React, { useState, useEffect } from 'react';
import { Search, ArrowUpDown, SlidersHorizontal, PackageX, ChevronRight, X } from 'lucide-react';
import { Product, FilterState } from '../types';
import { searchAndFilterProducts } from '../services/productService';
import { ProductCard } from '../components/product/ProductCard';

interface SearchResultsPageProps {
  initialQuery: string;
  onSelectProduct: (product: Product) => void;
  onWatchVideo: (product: Product) => void;
  onNavigateHome: () => void;
}

export const SearchResultsPage: React.FC<SearchResultsPageProps> = ({
  initialQuery,
  onSelectProduct,
  onWatchVideo,
  onNavigateHome,
}) => {
  const [query, setQuery] = useState(initialQuery);
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [sortBy, setSortBy] = useState<FilterState['sortBy']>('popular');
  const [onlyWithVideo, setOnlyWithVideo] = useState(false);

  useEffect(() => {
    setQuery(initialQuery);
  }, [initialQuery]);

  useEffect(() => {
    let mounted = true;
    async function executeSearch() {
      setLoading(true);
      const res = await searchAndFilterProducts({
        searchQuery: query,
        sortBy,
        hasVideoReview: onlyWithVideo,
        brands: [],
      });
      if (mounted) {
        setProducts(res);
        setLoading(false);
      }
    }
    executeSearch();
    return () => {
      mounted = false;
    };
  }, [query, sortBy, onlyWithVideo]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Breadcrumb */}
      <nav className="flex items-center gap-1.5 text-xs text-slate-500">
        <button onClick={onNavigateHome} className="hover:text-blue-600 transition-colors">
          Home
        </button>
        <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
        <span className="font-semibold text-slate-800">Search Results</span>
      </nav>

      {/* Search Header Bar */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/90 shadow-2xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold text-slate-900 font-['Space_Grotesk']">
              {query ? `Search Results for "${query}"` : 'All Products Catalog'}
            </h1>
            <p className="text-xs text-slate-500 mt-1">
              Found {products.length} {products.length === 1 ? 'matching item' : 'matching items'}
            </p>
          </div>

          <div className="relative w-full md:w-96">
            <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search products, brands, tags, keywords..."
              className="w-full pl-9 pr-8 py-2.5 bg-slate-50 focus:bg-white text-xs sm:text-sm rounded-xl border border-slate-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-500/10 outline-none"
            />
            {query && (
              <button
                onClick={() => setQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>

        {/* Filter / Sort Controls */}
        <div className="mt-6 pt-4 border-t border-slate-100 flex flex-wrap items-center justify-between gap-4">
          <label className="flex items-center gap-2 text-xs font-semibold text-slate-700 cursor-pointer">
            <input
              type="checkbox"
              checked={onlyWithVideo}
              onChange={(e) => setOnlyWithVideo(e.target.checked)}
              className="rounded border-slate-300 text-blue-600 focus:ring-blue-500 w-4 h-4"
            />
            <span>Show Only Products with YouTube Reviews</span>
          </label>

          <div className="flex items-center gap-2">
            <ArrowUpDown className="w-3.5 h-3.5 text-slate-400" />
            <span className="text-xs text-slate-500">Sort by:</span>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as FilterState['sortBy'])}
              className="text-xs font-semibold text-slate-800 bg-slate-50 border border-slate-200 rounded-lg py-1 px-2.5 focus:outline-none"
            >
              <option value="popular">Popularity</option>
              <option value="latest">Latest</option>
              <option value="price-asc">Price: Low to High</option>
              <option value="price-desc">Price: High to Low</option>
              <option value="rating">Rating</option>
            </select>
          </div>
        </div>
      </div>

      {/* Grid */}
      {loading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {Array.from({ length: 8 }).map((_, i) => (
            <div key={i} className="bg-white rounded-2xl p-4 border border-slate-200 animate-pulse h-80" />
          ))}
        </div>
      ) : products.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
          {products.map((p) => (
            <ProductCard
              key={p.id}
              product={p}
              onSelect={onSelectProduct}
              onWatchVideo={onWatchVideo}
            />
          ))}
        </div>
      ) : (
        <div className="bg-white rounded-3xl border border-slate-200 p-12 text-center max-w-lg mx-auto shadow-xs">
          <div className="w-16 h-16 rounded-2xl bg-slate-100 text-slate-400 flex items-center justify-center mx-auto mb-4">
            <PackageX className="w-8 h-8" />
          </div>
          <h3 className="font-bold text-slate-800 text-lg mb-1">No products found</h3>
          <p className="text-xs text-slate-500 leading-relaxed">
            We couldn't find any products matching "{query}". Try checking for spelling errors or search by general category like "audio", "camera", or "shoes".
          </p>
          <button
            onClick={() => setQuery('')}
            className="mt-5 px-5 py-2 text-xs font-semibold text-blue-600 bg-blue-50 hover:bg-blue-100 rounded-full"
          >
            Clear Search
          </button>
        </div>
      )}
    </div>
  );
};
