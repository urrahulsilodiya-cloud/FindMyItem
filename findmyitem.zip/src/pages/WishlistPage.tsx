import React, { useState, useEffect } from 'react';
import { Heart, Trash2, ArrowRight, PackageX, ExternalLink, Video } from 'lucide-react';
import { Product } from '../types';
import { useWishlist } from '../context/WishlistContext';
import { getProduct } from '../services/productService';
import { ProductCard } from '../components/product/ProductCard';

interface WishlistPageProps {
  onSelectProduct: (product: Product) => void;
  onWatchVideo: (product: Product) => void;
  onNavigateHome: () => void;
}

export const WishlistPage: React.FC<WishlistPageProps> = ({
  onSelectProduct,
  onWatchVideo,
  onNavigateHome,
}) => {
  const { wishlistIds, clearWishlist, wishlistCount } = useWishlist();
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let mounted = true;
    async function loadWishlistItems() {
      setLoading(true);
      const items: Product[] = [];
      for (const id of wishlistIds) {
        const prod = await getProduct(id);
        if (prod) items.push(prod);
      }
      if (mounted) {
        setProducts(items);
        setLoading(false);
      }
    }
    loadWishlistItems();
    return () => {
      mounted = false;
    };
  }, [wishlistIds]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/90 shadow-2xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-rose-50 text-rose-700 mb-2">
            <Heart className="w-3.5 h-3.5 fill-rose-600 text-rose-600" />
            <span>Personal Watchlist</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold text-slate-900 font-['Space_Grotesk']">
            Saved Products ({wishlistCount})
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Compare your saved items, watch reviews, and check for price adjustments.
          </p>
        </div>

        {wishlistCount > 0 && (
          <button
            onClick={clearWishlist}
            className="px-4 py-2 rounded-xl text-xs font-semibold text-rose-600 hover:text-rose-700 bg-rose-50 hover:bg-rose-100 transition-colors flex items-center gap-1.5 self-start sm:self-auto"
          >
            <Trash2 className="w-4 h-4" />
            <span>Clear Wishlist</span>
          </button>
        )}
      </div>

      {/* Grid */}
      {loading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {Array.from({ length: 4 }).map((_, i) => (
            <div key={i} className="bg-white rounded-2xl p-4 border border-slate-200 animate-pulse h-80" />
          ))}
        </div>
      ) : products.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
          {products.map((p) => (
            <ProductCard
              key={p.id}
              product={p}
              onSelect={onSelectProduct}
              onWatchVideo={onWatchVideo}
            />
          ))}
        </div>
      ) : (
        <div className="bg-white rounded-3xl border border-slate-200 p-12 text-center max-w-md mx-auto shadow-xs">
          <div className="w-16 h-16 rounded-full bg-rose-50 text-rose-500 flex items-center justify-center mx-auto mb-4">
            <Heart className="w-8 h-8" />
          </div>
          <h3 className="font-bold text-slate-800 text-lg mb-1">Your wishlist is empty</h3>
          <p className="text-xs text-slate-500 leading-relaxed">
            Click the heart icon on any product card or details page to bookmark it for later review and price checking.
          </p>
          <button
            onClick={onNavigateHome}
            className="mt-6 px-6 py-2.5 rounded-full bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold transition-colors inline-flex items-center gap-1.5 shadow-md shadow-blue-500/20"
          >
            <span>Start Discovering Products</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      )}
    </div>
  );
};
