import React, { useState, useEffect } from 'react';
import {
  Star,
  ExternalLink,
  Heart,
  Video,
  CheckCircle2,
  XCircle,
  ShieldCheck,
  ChevronRight,
  Info,
  Clock,
  Sparkles,
  Share2,
} from 'lucide-react';
import { Product } from '../types';
import { getProduct, getRelatedProducts } from '../services/productService';
import { ProductGallery } from '../components/product/ProductGallery';
import { ProductCard } from '../components/product/ProductCard';
import { useWishlist } from '../context/WishlistContext';
import { useCurrency } from '../context/CurrencyContext';
import { useToast } from '../context/ToastContext';

interface ProductDetailsPageProps {
  productSlug: string;
  onSelectProduct: (product: Product) => void;
  onWatchVideo: (product: Product) => void;
  onNavigateCategory: (categorySlug: string) => void;
  onNavigateHome: () => void;
}

export const ProductDetailsPage: React.FC<ProductDetailsPageProps> = ({
  productSlug,
  onSelectProduct,
  onWatchVideo,
  onNavigateCategory,
  onNavigateHome,
}) => {
  const { isInWishlist, toggleWishlist } = useWishlist();
  const { formatPrice } = useCurrency();
  const { showToast } = useToast();

  const [product, setProduct] = useState<Product | null>(null);
  const [related, setRelated] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let mounted = true;
    async function loadData() {
      setLoading(true);
      window.scrollTo({ top: 0, behavior: 'smooth' });
      const item = await getProduct(productSlug);
      if (item && mounted) {
        setProduct(item);
        const rel = await getRelatedProducts(item, 4);
        setRelated(rel);
      }
      setLoading(false);
    }
    loadData();
    return () => {
      mounted = false;
    };
  }, [productSlug]);

  const handleShare = () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(window.location.href);
      showToast('Product link copied to clipboard!', 'success');
    }
  };

  if (loading) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-12 animate-pulse space-y-8">
        <div className="h-6 bg-slate-200 rounded w-1/4" />
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
          <div className="aspect-square bg-slate-200 rounded-3xl" />
          <div className="space-y-4">
            <div className="h-8 bg-slate-200 rounded w-3/4" />
            <div className="h-6 bg-slate-200 rounded w-1/3" />
            <div className="h-24 bg-slate-100 rounded" />
            <div className="h-12 bg-slate-200 rounded w-1/2" />
          </div>
        </div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="max-w-xl mx-auto text-center py-20 px-4">
        <h2 className="text-xl font-bold text-slate-800">Product Not Found</h2>
        <p className="text-sm text-slate-500 mt-2">The product you are looking for may have been removed or unpublished.</p>
        <button
          onClick={onNavigateHome}
          className="mt-6 px-6 py-2.5 bg-blue-600 text-white rounded-full text-sm font-semibold hover:bg-blue-700"
        >
          Explore Other Products
        </button>
      </div>
    );
  }

  const isSaved = isInWishlist(product.id);
  const hasVideo = Boolean(product.youtubeVideoId || product.youtubeUrl);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-12">
      {/* Breadcrumb Navigation */}
      <nav className="flex items-center gap-1.5 text-xs text-slate-500">
        <button onClick={onNavigateHome} className="hover:text-blue-600 transition-colors">
          Home
        </button>
        <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
        <button
          onClick={() => onNavigateCategory(product.categoryId)}
          className="hover:text-blue-600 transition-colors capitalize"
        >
          {product.categoryId.replace('cat-', '')}
        </button>
        <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
        <span className="font-semibold text-slate-800 line-clamp-1">{product.name}</span>
      </nav>

      {/* Main Showcase: Gallery (Left) & Key Specs / Buy Actions (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 bg-white rounded-3xl p-6 sm:p-10 border border-slate-200/90 shadow-2xs">
        
        {/* Gallery: 6 cols */}
        <div className="lg:col-span-6">
          <ProductGallery images={product.images} productName={product.name} />
        </div>

        {/* Product Details & Actions: 6 cols */}
        <div className="lg:col-span-6 flex flex-col justify-between">
          <div>
            {/* Brand, Rating & Share */}
            <div className="flex items-center justify-between gap-4 mb-2">
              <span className="text-xs font-bold text-blue-600 uppercase tracking-wider">
                {product.brand}
              </span>
              <div className="flex items-center gap-2">
                <button
                  onClick={handleShare}
                  className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition-colors"
                  title="Share product link"
                >
                  <Share2 className="w-4 h-4" />
                </button>
                <button
                  onClick={() => toggleWishlist(product.id)}
                  className={`p-1.5 rounded-lg transition-colors ${
                    isSaved ? 'text-rose-600 bg-rose-50' : 'text-slate-400 hover:text-rose-500 hover:bg-slate-100'
                  }`}
                  title={isSaved ? 'Remove from wishlist' : 'Save to wishlist'}
                >
                  <Heart className={`w-4 h-4 ${isSaved ? 'fill-rose-500' : ''}`} />
                </button>
              </div>
            </div>

            {/* Title */}
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight font-['Space_Grotesk'] leading-snug">
              {product.name}
            </h1>

            {/* Rating Bar */}
            <div className="mt-3 flex items-center gap-3">
              <div className="flex items-center gap-1.5 bg-amber-50 px-2.5 py-1 rounded-lg">
                <Star className="w-4 h-4 fill-amber-400 text-amber-500" />
                <span className="font-bold text-xs text-slate-800">{product.rating.toFixed(1)}</span>
                <span className="text-slate-400 text-xs">/ 5.0</span>
              </div>
              <span className="text-xs text-slate-500">
                Based on {product.reviewCount.toLocaleString()} aggregated user ratings
              </span>
            </div>

            {/* Price Box */}
            <div className="mt-6 p-4 rounded-2xl bg-slate-50 border border-slate-200/80">
              <div className="flex items-baseline gap-3">
                <span className="text-3xl font-extrabold text-slate-900">
                  {formatPrice(product.price)}
                </span>
                {product.originalPrice && product.originalPrice > product.price && (
                  <span className="text-sm text-slate-400 line-through">
                    {formatPrice(product.originalPrice)}
                  </span>
                )}
                {product.discount && product.discount > 0 && (
                  <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-rose-100 text-rose-700">
                    Save {product.discount}%
                  </span>
                )}
              </div>
              <div className="mt-1 flex items-center gap-1 text-xs text-slate-500">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                <span>Verified price estimate via verified retailer: <strong>{product.sellerName}</strong></span>
              </div>
            </div>

            {/* Short Description */}
            <div className="mt-5">
              <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">
                Overview
              </h3>
              <p className="text-sm text-slate-600 leading-relaxed">
                {product.shortDescription}
              </p>
            </div>
          </div>

          {/* CTAs & Marketplace Disclaimer */}
          <div className="mt-8 pt-6 border-t border-slate-100 space-y-3">
            <div className="flex flex-col sm:flex-row gap-3">
              <a
                href={product.buyUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex-1 py-3.5 px-6 rounded-2xl text-sm font-bold text-white bg-blue-600 hover:bg-blue-700 transition-colors shadow-md shadow-blue-500/20 flex items-center justify-center gap-2 text-center"
              >
                <span>Buy Product on {product.sellerName}</span>
                <ExternalLink className="w-4 h-4" />
              </a>

              {hasVideo && (
                <button
                  onClick={() => onWatchVideo(product)}
                  className="py-3.5 px-6 rounded-2xl text-sm font-semibold text-red-600 bg-red-50 hover:bg-red-100 transition-colors flex items-center justify-center gap-2"
                >
                  <Video className="w-4 h-4" />
                  <span>Watch Review</span>
                </button>
              )}
            </div>

            {/* Strict Marketplace Transparency Note */}
            <div className="p-3 rounded-xl bg-slate-50 text-[11px] text-slate-500 flex items-start gap-2 border border-slate-200/60">
              <Info className="w-4 h-4 text-blue-500 shrink-0 mt-0.5" />
              <span>
                <strong>FindMyItem Notice:</strong> FindMyItem is an independent discovery and review platform. Clicking "Buy Product" takes you directly to the verified external retailer's official website ({product.sellerName}) where checkout and shipment are processed.
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Tabs / Deep-Dive Sections: Specs, Pros/Cons, Full Description, How to Use */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Left 2 Cols: Detailed Description & How To Use */}
        <div className="lg:col-span-2 space-y-8">
          
          {/* Detailed Description */}
          <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/90 shadow-2xs space-y-4">
            <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2 font-['Space_Grotesk']">
              <Sparkles className="w-5 h-5 text-blue-600" />
              About This Product
            </h2>
            <div className="text-sm text-slate-700 leading-relaxed space-y-3">
              <p>{product.description}</p>
            </div>
          </div>

          {/* Pros & Cons */}
          <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/90 shadow-2xs">
            <h2 className="text-lg font-bold text-slate-900 mb-6 font-['Space_Grotesk']">
              Pros & Cons Analysis
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              {/* Pros */}
              <div className="space-y-3 bg-emerald-50/50 p-4 rounded-2xl border border-emerald-100">
                <div className="flex items-center gap-2 text-emerald-800 font-bold text-xs uppercase tracking-wider">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>The Highlights (Pros)</span>
                </div>
                <ul className="space-y-2">
                  {product.pros.map((pro, i) => (
                    <li key={i} className="text-xs text-slate-700 flex items-start gap-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 shrink-0 mt-1.5" />
                      <span>{pro}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Cons */}
              <div className="space-y-3 bg-rose-50/50 p-4 rounded-2xl border border-rose-100">
                <div className="flex items-center gap-2 text-rose-800 font-bold text-xs uppercase tracking-wider">
                  <XCircle className="w-4 h-4 text-rose-600" />
                  <span>Things to Consider (Cons)</span>
                </div>
                <ul className="space-y-2">
                  {product.cons.map((con, i) => (
                    <li key={i} className="text-xs text-slate-700 flex items-start gap-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-rose-500 shrink-0 mt-1.5" />
                      <span>{con}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>

          {/* How To Use */}
          {product.howToUse && (
            <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/90 shadow-2xs space-y-3">
              <h2 className="text-lg font-bold text-slate-900 font-['Space_Grotesk']">
                How To Use & Setup Guide
              </h2>
              <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                {product.howToUse}
              </p>
            </div>
          )}

          {/* YouTube Video Review Embed */}
          {hasVideo && (
            <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/90 shadow-2xs space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Video className="w-5 h-5 text-red-600" />
                  <h2 className="text-lg font-bold text-slate-900 font-['Space_Grotesk']">
                    Video Review & Hands-On Test
                  </h2>
                </div>
                <span className="text-xs font-semibold text-red-600 bg-red-50 px-2.5 py-0.5 rounded-full">
                  YouTube Breakdown
                </span>
              </div>
              <p className="text-xs text-slate-500">
                {product.youtubeTitle || `Comprehensive hands-on breakdown for ${product.name}`}
              </p>
              
              <div className="relative aspect-video rounded-2xl overflow-hidden bg-black shadow-md">
                {product.youtubeVideoId ? (
                  <iframe
                    className="w-full h-full"
                    src={`https://www.youtube-nocookie.com/embed/${product.youtubeVideoId}?rel=0`}
                    title={product.youtubeTitle || product.name}
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowFullScreen
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-slate-400">
                    <a
                      href={product.youtubeUrl}
                      target="_blank"
                      rel="noreferrer"
                      className="text-white hover:underline flex items-center gap-2"
                    >
                      <Video className="w-5 h-5 text-red-500" /> Watch Review on YouTube
                    </a>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Right Col: Specifications Table */}
        <div className="space-y-6">
          <div className="bg-white rounded-3xl p-6 border border-slate-200/90 shadow-2xs">
            <h2 className="text-base font-bold text-slate-900 mb-4 font-['Space_Grotesk']">
              Technical Specifications
            </h2>
            <div className="divide-y divide-slate-100 text-xs">
              {product.specifications.map((spec, i) => (
                <div key={i} className="py-2.5 flex items-center justify-between gap-4">
                  <span className="text-slate-500 font-medium">{spec.label}</span>
                  <span className="text-slate-900 font-semibold text-right">{spec.value}</span>
                </div>
              ))}
              <div className="py-2.5 flex items-center justify-between gap-4">
                <span className="text-slate-500 font-medium">Brand</span>
                <span className="text-slate-900 font-semibold text-right">{product.brand}</span>
              </div>
              <div className="py-2.5 flex items-center justify-between gap-4">
                <span className="text-slate-500 font-medium">Seller Source</span>
                <span className="text-slate-900 font-semibold text-right">{product.sellerName}</span>
              </div>
              <div className="py-2.5 flex items-center justify-between gap-4">
                <span className="text-slate-500 font-medium">Stock Status</span>
                <span className="text-emerald-700 font-semibold text-right">In Stock</span>
              </div>
            </div>
          </div>

          {/* Tags */}
          {product.tags && product.tags.length > 0 && (
            <div className="bg-white rounded-3xl p-6 border border-slate-200/90 shadow-2xs">
              <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3">
                Related Tags
              </h3>
              <div className="flex flex-wrap gap-1.5">
                {product.tags.map((tag) => (
                  <span
                    key={tag}
                    className="px-2.5 py-1 rounded-full text-xs font-medium bg-slate-100 text-slate-700"
                  >
                    #{tag}
                  </span>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* SECTION: Related Products */}
      {related.length > 0 && (
        <section className="space-y-6 pt-6 border-t border-slate-200">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-xl font-bold text-slate-900 font-['Space_Grotesk']">
                Related Products You Might Like
              </h2>
              <p className="text-xs text-slate-500">Based on brand, subcategory, and matching tags</p>
            </div>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {related.map((relProduct) => (
              <ProductCard
                key={relProduct.id}
                product={relProduct}
                onSelect={onSelectProduct}
                onWatchVideo={onWatchVideo}
              />
            ))}
          </div>
        </section>
      )}
    </div>
  );
};
