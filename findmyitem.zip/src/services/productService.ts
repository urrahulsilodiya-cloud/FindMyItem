import { Product, FilterState } from '../types';
import { getProducts, getProductBySlug, saveProduct, deleteProduct } from './storageService';

export async function getAllProducts(): Promise<Product[]> {
  return await getProducts();
}

export async function getPublishedProducts(): Promise<Product[]> {
  const all = await getProducts();
  return all.filter((p) => p.published);
}

export async function getProduct(slugOrId: string): Promise<Product | undefined> {
  return await getProductBySlug(slugOrId);
}

export async function getRelatedProducts(product: Product, limit = 4): Promise<Product[]> {
  const all = await getPublishedProducts();
  return all
    .filter((p) => p.id !== product.id)
    .map((p) => {
      let score = 0;
      if (p.categoryId === product.categoryId) score += 3;
      if (p.subcategoryId && p.subcategoryId === product.subcategoryId) score += 4;
      if (p.brand.toLowerCase() === product.brand.toLowerCase()) score += 2;
      const commonTags = p.tags.filter((t) => product.tags.includes(t));
      score += commonTags.length;
      return { product: p, score };
    })
    .sort((a, b) => b.score - a.score)
    .slice(0, limit)
    .map((item) => item.product);
}

export async function getRecommendedProducts(categoryIdsOrSlugs: string[], limit = 6): Promise<Product[]> {
  const all = await getPublishedProducts();
  if (!categoryIdsOrSlugs || categoryIdsOrSlugs.length === 0) {
    return all.slice(0, limit);
  }
  const matched = all.filter((p) =>
    categoryIdsOrSlugs.includes(p.categoryId) ||
    categoryIdsOrSlugs.some((cat) => p.tags.includes(cat.toLowerCase()))
  );
  if (matched.length >= limit) {
    return matched.slice(0, limit);
  }
  // Fill remainder with popular/featured products
  const remainder = all.filter((p) => !matched.some((m) => m.id === p.id));
  return [...matched, ...remainder].slice(0, limit);
}

export async function getTrendingInInterests(categoryIdsOrSlugs: string[], limit = 6): Promise<Product[]> {
  const all = await getPublishedProducts();
  const filtered = categoryIdsOrSlugs.length > 0
    ? all.filter((p) => categoryIdsOrSlugs.includes(p.categoryId))
    : all;

  return [...filtered]
    .sort((a, b) => b.rating * b.reviewCount - a.rating * a.reviewCount)
    .slice(0, limit);
}

export async function getLatestProducts(limit = 6): Promise<Product[]> {
  const all = await getPublishedProducts();
  return [...all]
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    .slice(0, limit);
}

export async function getPopularProducts(limit = 6): Promise<Product[]> {
  const all = await getPublishedProducts();
  return [...all]
    .sort((a, b) => b.reviewCount - a.reviewCount)
    .slice(0, limit);
}

export async function getProductsWithReviews(limit = 8): Promise<Product[]> {
  const all = await getPublishedProducts();
  return all.filter((p) => Boolean(p.youtubeVideoId || p.youtubeUrl)).slice(0, limit);
}

export async function searchAndFilterProducts(filter: FilterState): Promise<Product[]> {
  let list = await getPublishedProducts();

  if (filter.categorySlug) {
    // Note: categorySlug might be ID or slug
    list = list.filter((p) => p.categoryId === filter.categorySlug || p.categoryId.includes(filter.categorySlug!));
  }

  if (filter.subcategorySlug) {
    list = list.filter((p) => p.subcategoryId === filter.subcategorySlug || p.subcategoryId.includes(filter.subcategorySlug!));
  }

  if (filter.searchQuery && filter.searchQuery.trim() !== '') {
    const q = filter.searchQuery.toLowerCase().trim();
    list = list.filter((p) => {
      const matchName = p.name.toLowerCase().includes(q);
      const matchBrand = p.brand.toLowerCase().includes(q);
      const matchDesc = p.shortDescription.toLowerCase().includes(q) || p.description.toLowerCase().includes(q);
      const matchTags = p.tags.some((t) => t.toLowerCase().includes(q));
      return matchName || matchBrand || matchDesc || matchTags;
    });
  }

  if (filter.brands && filter.brands.length > 0) {
    list = list.filter((p) => filter.brands.includes(p.brand));
  }

  if (filter.minPrice !== undefined) {
    list = list.filter((p) => p.price >= filter.minPrice!);
  }

  if (filter.maxPrice !== undefined) {
    list = list.filter((p) => p.price <= filter.maxPrice!);
  }

  if (filter.minRating !== undefined && filter.minRating > 0) {
    list = list.filter((p) => p.rating >= filter.minRating!);
  }

  if (filter.hasVideoReview) {
    list = list.filter((p) => Boolean(p.youtubeVideoId || p.youtubeUrl));
  }

  switch (filter.sortBy) {
    case 'latest':
      list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      break;
    case 'price-asc':
      list.sort((a, b) => a.price - b.price);
      break;
    case 'price-desc':
      list.sort((a, b) => b.price - a.price);
      break;
    case 'rating':
      list.sort((a, b) => b.rating - a.rating);
      break;
    case 'popular':
    default:
      list.sort((a, b) => b.reviewCount - a.reviewCount);
      break;
  }

  return list;
}

export async function createProduct(productData: Omit<Product, 'id' | 'createdAt' | 'updatedAt'>): Promise<Product> {
  const newProduct: Product = {
    ...productData,
    id: `prod-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };
  await saveProduct(newProduct);
  return newProduct;
}

export async function updateProduct(product: Product): Promise<void> {
  await saveProduct(product);
}

export async function removeProduct(productId: string): Promise<void> {
  await deleteProduct(productId);
}
