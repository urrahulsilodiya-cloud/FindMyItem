import { Category, Subcategory } from '../types';
import {
  getCategories,
  saveCategory,
  deleteCategory,
  getSubcategories,
  saveSubcategory,
  deleteSubcategory,
} from './storageService';

export async function getAllCategories(): Promise<Category[]> {
  const list = await getCategories();
  return list.sort((a, b) => a.displayOrder - b.displayOrder);
}

export async function getActiveCategories(): Promise<Category[]> {
  const list = await getAllCategories();
  return list.filter((c) => c.isActive);
}

export async function getCategory(idOrSlug: string): Promise<Category | undefined> {
  const list = await getAllCategories();
  return list.find((c) => c.id === idOrSlug || c.slug === idOrSlug);
}

export async function createCategory(cat: Omit<Category, 'id'>): Promise<Category> {
  const newCat: Category = {
    ...cat,
    id: `cat-${cat.slug || Date.now()}`,
  };
  await saveCategory(newCat);
  return newCat;
}

export async function updateCategory(category: Category): Promise<void> {
  await saveCategory(category);
}

export async function removeCategory(categoryId: string): Promise<void> {
  await deleteCategory(categoryId);
}

export async function getAllSubcategories(): Promise<Subcategory[]> {
  const list = await getSubcategories();
  return list.sort((a, b) => a.displayOrder - b.displayOrder);
}

export async function getSubcategoriesForCategory(categoryId: string): Promise<Subcategory[]> {
  const list = await getAllSubcategories();
  return list.filter((s) => s.parentCategoryId === categoryId && s.isActive);
}

export async function createSubcategory(sub: Omit<Subcategory, 'id'>): Promise<Subcategory> {
  const newSub: Subcategory = {
    ...sub,
    id: `sub-${sub.slug || Date.now()}`,
  };
  await saveSubcategory(newSub);
  return newSub;
}

export async function updateSubcategory(sub: Subcategory): Promise<void> {
  await saveSubcategory(sub);
}

export {
  saveCategory,
  deleteCategory,
  saveSubcategory,
  deleteSubcategory,
};
