import { Category, Subcategory, Product, SiteSettings } from '../types';
import { INITIAL_CATEGORIES, INITIAL_SUBCATEGORIES, INITIAL_PRODUCTS, INITIAL_SETTINGS } from '../data/seedData';
import { isFirebaseConfigured, db } from '../firebase/config';
import {
  collection,
  doc,
  getDocs,
  getDoc,
  setDoc,
  deleteDoc,
  updateDoc
} from 'firebase/firestore';

const STORAGE_KEYS = {
  CATEGORIES: 'findmyitem_categories_v1',
  SUBCATEGORIES: 'findmyitem_subcategories_v1',
  PRODUCTS: 'findmyitem_products_v1',
  SETTINGS: 'findmyitem_settings_v1',
  WISHLISTS: 'findmyitem_wishlists_v1',
  USERS: 'findmyitem_users_v1',
};

type Listener = () => void;
const listeners = new Set<Listener>();

function notifyListeners() {
  listeners.forEach((listener) => {
    try {
      listener();
    } catch (e) {
      console.error('Listener notification error:', e);
    }
  });
}

export function subscribeToDataChanges(callback: Listener): () => void {
  listeners.add(callback);
  return () => {
    listeners.delete(callback);
  };
}

// Local storage helpers
function readLocal<T>(key: string, defaultValue: T): T {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return defaultValue;
    return JSON.parse(raw);
  } catch {
    return defaultValue;
  }
}

function writeLocal<T>(key: string, value: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(value));
    notifyListeners();
  } catch (err) {
    console.warn(`Failed writing ${key} to localStorage:`, err);
  }
}

// Ensure initial seed data exists in local storage
export function initializeStorage(): void {
  if (!localStorage.getItem(STORAGE_KEYS.CATEGORIES)) {
    writeLocal(STORAGE_KEYS.CATEGORIES, INITIAL_CATEGORIES);
  }
  if (!localStorage.getItem(STORAGE_KEYS.SUBCATEGORIES)) {
    writeLocal(STORAGE_KEYS.SUBCATEGORIES, INITIAL_SUBCATEGORIES);
  }
  if (!localStorage.getItem(STORAGE_KEYS.PRODUCTS)) {
    writeLocal(STORAGE_KEYS.PRODUCTS, INITIAL_PRODUCTS);
  }
  if (!localStorage.getItem(STORAGE_KEYS.SETTINGS)) {
    writeLocal(STORAGE_KEYS.SETTINGS, INITIAL_SETTINGS);
  }
}

export function resetToSeedData(): void {
  writeLocal(STORAGE_KEYS.CATEGORIES, INITIAL_CATEGORIES);
  writeLocal(STORAGE_KEYS.SUBCATEGORIES, INITIAL_SUBCATEGORIES);
  writeLocal(STORAGE_KEYS.PRODUCTS, INITIAL_PRODUCTS);
  writeLocal(STORAGE_KEYS.SETTINGS, INITIAL_SETTINGS);
}

export const resetToInitialData = resetToSeedData;

// ===================== CATEGORIES =====================
export async function getCategories(): Promise<Category[]> {
  if (isFirebaseConfigured && db) {
    try {
      const snap = await getDocs(collection(db, 'categories'));
      if (!snap.empty) {
        return snap.docs.map((d) => d.data() as Category).sort((a, b) => a.displayOrder - b.displayOrder);
      }
    } catch (err) {
      console.warn('Firestore getCategories failed, falling back to local storage:', err);
    }
  }
  initializeStorage();
  const list = readLocal<Category[]>(STORAGE_KEYS.CATEGORIES, INITIAL_CATEGORIES);
  return list.sort((a, b) => a.displayOrder - b.displayOrder);
}

export async function saveCategory(category: Category): Promise<void> {
  const existing = await getCategories();
  const index = existing.findIndex((c) => c.id === category.id);
  let updated: Category[];
  if (index >= 0) {
    updated = [...existing];
    updated[index] = category;
  } else {
    updated = [...existing, category];
  }
  writeLocal(STORAGE_KEYS.CATEGORIES, updated);

  if (isFirebaseConfigured && db) {
    try {
      await setDoc(doc(db, 'categories', category.id), category);
    } catch (err) {
      console.warn('Firestore setDoc category error:', err);
    }
  }
}

export async function deleteCategory(categoryId: string): Promise<void> {
  const existing = await getCategories();
  const updated = existing.filter((c) => c.id !== categoryId);
  writeLocal(STORAGE_KEYS.CATEGORIES, updated);

  if (isFirebaseConfigured && db) {
    try {
      await deleteDoc(doc(db, 'categories', categoryId));
    } catch (err) {
      console.warn('Firestore deleteDoc category error:', err);
    }
  }
}

// ===================== SUBCATEGORIES =====================
export async function getSubcategories(): Promise<Subcategory[]> {
  if (isFirebaseConfigured && db) {
    try {
      const snap = await getDocs(collection(db, 'subcategories'));
      if (!snap.empty) {
        return snap.docs.map((d) => d.data() as Subcategory).sort((a, b) => a.displayOrder - b.displayOrder);
      }
    } catch (err) {
      console.warn('Firestore getSubcategories failed, fallback to local storage:', err);
    }
  }
  initializeStorage();
  const list = readLocal<Subcategory[]>(STORAGE_KEYS.SUBCATEGORIES, INITIAL_SUBCATEGORIES);
  return list.sort((a, b) => a.displayOrder - b.displayOrder);
}

export async function saveSubcategory(subcategory: Subcategory): Promise<void> {
  const existing = await getSubcategories();
  const index = existing.findIndex((s) => s.id === subcategory.id);
  let updated: Subcategory[];
  if (index >= 0) {
    updated = [...existing];
    updated[index] = subcategory;
  } else {
    updated = [...existing, subcategory];
  }
  writeLocal(STORAGE_KEYS.SUBCATEGORIES, updated);

  if (isFirebaseConfigured && db) {
    try {
      await setDoc(doc(db, 'subcategories', subcategory.id), subcategory);
    } catch (err) {
      console.warn('Firestore setDoc subcategory error:', err);
    }
  }
}

export async function deleteSubcategory(subcategoryId: string): Promise<void> {
  const existing = await getSubcategories();
  const updated = existing.filter((s) => s.id !== subcategoryId);
  writeLocal(STORAGE_KEYS.SUBCATEGORIES, updated);

  if (isFirebaseConfigured && db) {
    try {
      await deleteDoc(doc(db, 'subcategories', subcategoryId));
    } catch (err) {
      console.warn('Firestore deleteDoc subcategory error:', err);
    }
  }
}

// ===================== PRODUCTS =====================
export async function getProducts(): Promise<Product[]> {
  if (isFirebaseConfigured && db) {
    try {
      const snap = await getDocs(collection(db, 'products'));
      if (!snap.empty) {
        return snap.docs.map((d) => d.data() as Product);
      }
    } catch (err) {
      console.warn('Firestore getProducts failed, fallback to local storage:', err);
    }
  }
  initializeStorage();
  return readLocal<Product[]>(STORAGE_KEYS.PRODUCTS, INITIAL_PRODUCTS);
}

export async function getProductBySlug(slug: string): Promise<Product | undefined> {
  const products = await getProducts();
  return products.find((p) => p.slug === slug || p.id === slug);
}

export async function saveProduct(product: Product): Promise<void> {
  const existing = await getProducts();
  const index = existing.findIndex((p) => p.id === product.id);
  let updated: Product[];
  if (index >= 0) {
    updated = [...existing];
    updated[index] = { ...product, updatedAt: new Date().toISOString() };
  } else {
    updated = [
      { ...product, createdAt: product.createdAt || new Date().toISOString(), updatedAt: new Date().toISOString() },
      ...existing,
    ];
  }
  writeLocal(STORAGE_KEYS.PRODUCTS, updated);

  if (isFirebaseConfigured && db) {
    try {
      await setDoc(doc(db, 'products', product.id), product);
    } catch (err) {
      console.warn('Firestore setDoc product error:', err);
    }
  }
}

export async function deleteProduct(productId: string): Promise<void> {
  const existing = await getProducts();
  const updated = existing.filter((p) => p.id !== productId);
  writeLocal(STORAGE_KEYS.PRODUCTS, updated);

  if (isFirebaseConfigured && db) {
    try {
      await deleteDoc(doc(db, 'products', productId));
    } catch (err) {
      console.warn('Firestore deleteDoc product error:', err);
    }
  }
}

// ===================== SETTINGS =====================
export async function getSettings(): Promise<SiteSettings> {
  if (isFirebaseConfigured && db) {
    try {
      const snap = await getDoc(doc(db, 'settings', 'global'));
      if (snap.exists()) {
        return snap.data() as SiteSettings;
      }
    } catch (err) {
      console.warn('Firestore getSettings error, fallback to local storage:', err);
    }
  }
  initializeStorage();
  return readLocal<SiteSettings>(STORAGE_KEYS.SETTINGS, INITIAL_SETTINGS);
}

export async function saveSettings(settings: SiteSettings): Promise<void> {
  writeLocal(STORAGE_KEYS.SETTINGS, settings);
  if (isFirebaseConfigured && db) {
    try {
      await setDoc(doc(db, 'settings', 'global'), settings);
    } catch (err) {
      console.warn('Firestore saveSettings error:', err);
    }
  }
}

// ===================== WISHLIST =====================
export function getStoredWishlist(userId: string): string[] {
  const allWishlists = readLocal<Record<string, string[]>>(STORAGE_KEYS.WISHLISTS, {});
  return allWishlists[userId] || [];
}

export function saveStoredWishlist(userId: string, productIds: string[]): void {
  const allWishlists = readLocal<Record<string, string[]>>(STORAGE_KEYS.WISHLISTS, {});
  allWishlists[userId] = productIds;
  writeLocal(STORAGE_KEYS.WISHLISTS, allWishlists);

  if (isFirebaseConfigured && db && userId !== 'guest') {
    try {
      setDoc(doc(db, 'wishlists', userId), { userId, productIds, updatedAt: new Date().toISOString() });
    } catch (err) {
      console.warn('Firestore saveWishlist error:', err);
    }
  }
}
