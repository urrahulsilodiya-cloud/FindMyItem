import React, { useState, useEffect } from 'react';
import { AuthProvider } from './context/AuthContext';
import { CurrencyProvider } from './context/CurrencyContext';
import { WishlistProvider } from './context/WishlistContext';
import { ToastProvider } from './context/ToastContext';
import { Navbar } from './components/common/Navbar';
import { Footer } from './components/common/Footer';
import { VideoModal } from './components/common/VideoModal';
import { AuthModal } from './components/common/AuthModal';

import { HomePage } from './pages/HomePage';
import { CategoryPage } from './pages/CategoryPage';
import { ProductDetailsPage } from './pages/ProductDetailsPage';
import { SearchResultsPage } from './pages/SearchResultsPage';
import { ReviewsPage } from './pages/ReviewsPage';
import { WishlistPage } from './pages/WishlistPage';
import { AdminDashboard } from './pages/AdminDashboard';
import { Product } from './types';

function MainApp() {
  const [route, setRoute] = useState<string>('home');
  const [routeParam, setRouteParam] = useState<string>('');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [activeVideoProduct, setActiveVideoProduct] = useState<Product | null>(null);
  const [isAuthOpen, setIsAuthOpen] = useState<boolean>(false);

  // Parse hash on initial load or popstate
  useEffect(() => {
    const handleHashChange = () => {
      const hash = window.location.hash.replace('#', '') || 'home';
      const parts = hash.split('/');
      const mainRoute = parts[0] || 'home';
      const param = parts[1] || '';

      setRoute(mainRoute);
      setRouteParam(param);
      if (mainRoute === 'search' && param) {
        setSearchQuery(decodeURIComponent(param));
      }
    };

    handleHashChange();
    window.addEventListener('hashchange', handleHashChange);
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  const navigate = (newRoute: string, param?: string) => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
    setRoute(newRoute);
    setRouteParam(param || '');
    if (param) {
      window.location.hash = `${newRoute}/${param}`;
    } else {
      window.location.hash = newRoute;
    }
  };

  const handleSearchSubmit = (query: string) => {
    if (!query.trim()) return;
    navigate('search', encodeURIComponent(query.trim()));
  };

  const handleSelectProduct = (product: Product) => {
    navigate('product', product.slug || product.id);
  };

  const handleWatchVideo = (product: Product) => {
    setActiveVideoProduct(product);
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50/60 text-slate-900 font-sans selection:bg-blue-500 selection:text-white">
      {/* Global Navigation */}
      <Navbar
        currentRoute={route}
        onNavigate={navigate}
        onOpenAuth={() => setIsAuthOpen(true)}
        onSearchSubmit={handleSearchSubmit}
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
      />

      {/* Main Content Area */}
      <main className="flex-1">
        {route === 'home' && (
          <HomePage
            forceShowPicker={routeParam === 'interests'}
            onSelectProduct={handleSelectProduct}
            onWatchVideo={handleWatchVideo}
            onNavigateCategory={(slug) => navigate('category', slug)}
            onNavigateReviews={() => navigate('reviews')}
          />
        )}

        {route === 'category' && (
          <CategoryPage
            categorySlug={routeParam}
            onSelectProduct={handleSelectProduct}
            onWatchVideo={handleWatchVideo}
            onNavigateHome={() => navigate('home')}
          />
        )}

        {route === 'product' && (
          <ProductDetailsPage
            productSlug={routeParam}
            onSelectProduct={handleSelectProduct}
            onWatchVideo={handleWatchVideo}
            onNavigateCategory={(slug) => navigate('category', slug)}
            onNavigateHome={() => navigate('home')}
          />
        )}

        {route === 'search' && (
          <SearchResultsPage
            initialQuery={routeParam ? decodeURIComponent(routeParam) : searchQuery}
            onSelectProduct={handleSelectProduct}
            onWatchVideo={handleWatchVideo}
            onNavigateHome={() => navigate('home')}
          />
        )}

        {(route === 'reviews' || route === 'youtube') && (
          <ReviewsPage
            onSelectProduct={handleSelectProduct}
            onWatchVideo={handleWatchVideo}
            onNavigateHome={() => navigate('home')}
          />
        )}

        {route === 'wishlist' && (
          <WishlistPage
            onSelectProduct={handleSelectProduct}
            onWatchVideo={handleWatchVideo}
            onNavigateHome={() => navigate('home')}
          />
        )}

        {route === 'admin' && (
          <AdminDashboard
            onNavigateHome={() => navigate('home')}
            onPreviewProduct={handleSelectProduct}
          />
        )}
      </main>

      {/* Global Footer */}
      <Footer onNavigate={navigate} />

      {/* Global Video Modal */}
      {activeVideoProduct && (
        <VideoModal
          product={activeVideoProduct}
          onClose={() => setActiveVideoProduct(null)}
          onSelectProduct={handleSelectProduct}
        />
      )}

      {/* Global Auth Modal */}
      <AuthModal isOpen={isAuthOpen} onClose={() => setIsAuthOpen(false)} />
    </div>
  );
}

export default function App() {
  return (
    <ToastProvider>
      <AuthProvider>
        <CurrencyProvider>
          <WishlistProvider>
            <MainApp />
          </WishlistProvider>
        </CurrencyProvider>
      </AuthProvider>
    </ToastProvider>
  );
}
