import React, { createContext, useContext, useState, useEffect } from 'react';
import { UserProfile, UserRole } from '../types';
import { isFirebaseConfigured, auth } from '../firebase/config';
import {
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut as fbSignOut,
  onAuthStateChanged,
} from 'firebase/auth';

interface AuthContextValue {
  user: UserProfile | null;
  isAdmin: boolean;
  login: (email: string, password?: string) => Promise<boolean>;
  signup: (name: string, email: string, password?: string) => Promise<boolean>;
  logout: () => Promise<void>;
  updateInterests: (interests: string[]) => void;
  switchRole: (role: UserRole) => void;
  loginAsAdmin: () => void;
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

const LOCAL_USER_KEY = 'findmyitem_current_user_v1';

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<UserProfile | null>(() => {
    try {
      const stored = localStorage.getItem(LOCAL_USER_KEY);
      if (stored) return JSON.parse(stored);
    } catch (e) {
      console.error(e);
    }
    // Default guest profile with admin switcher convenience
    return {
      uid: 'user-demo-123',
      name: 'Alex Walker',
      email: 'alex@findmyitem.com',
      role: 'user',
      selectedInterests: ['cat-fashion', 'cat-gaming', 'cat-audio'],
      createdAt: new Date().toISOString(),
    };
  });

  useEffect(() => {
    if (user) {
      localStorage.setItem(LOCAL_USER_KEY, JSON.stringify(user));
    } else {
      localStorage.removeItem(LOCAL_USER_KEY);
    }
  }, [user]);

  // Optional Firebase auth listener
  useEffect(() => {
    if (!isFirebaseConfigured || !auth) return;
    const unsub = onAuthStateChanged(auth, (fbUser) => {
      if (fbUser) {
        setUser((prev) => ({
          uid: fbUser.uid,
          name: fbUser.displayName || fbUser.email?.split('@')[0] || 'User',
          email: fbUser.email || '',
          role: prev?.role || 'user',
          selectedInterests: prev?.selectedInterests || [],
        }));
      }
    });
    return () => unsub();
  }, []);

  const login = async (email: string, password?: string): Promise<boolean> => {
    if (isFirebaseConfigured && auth && password) {
      try {
        const cred = await signInWithEmailAndPassword(auth, email, password);
        const isAdmin = email.toLowerCase().includes('admin');
        setUser({
          uid: cred.user.uid,
          name: cred.user.displayName || email.split('@')[0],
          email: cred.user.email || email,
          role: isAdmin ? 'admin' : 'user',
          selectedInterests: ['cat-fashion', 'cat-mobile'],
        });
        return true;
      } catch (err) {
        console.warn('Firebase login failed, falling back to local login:', err);
      }
    }

    // Local authentication fallback
    const isAdmin = email.toLowerCase().includes('admin');
    const newUser: UserProfile = {
      uid: `usr-${Date.now()}`,
      name: email.split('@')[0],
      email: email,
      role: isAdmin ? 'admin' : 'user',
      selectedInterests: ['cat-fashion', 'cat-mobile', 'cat-gaming'],
      createdAt: new Date().toISOString(),
    };
    setUser(newUser);
    return true;
  };

  const signup = async (name: string, email: string, password?: string): Promise<boolean> => {
    if (isFirebaseConfigured && auth && password) {
      try {
        const cred = await createUserWithEmailAndPassword(auth, email, password);
        setUser({
          uid: cred.user.uid,
          name,
          email,
          role: 'user',
          selectedInterests: [],
        });
        return true;
      } catch (err) {
        console.warn('Firebase signup failed, using local fallback:', err);
      }
    }

    const newUser: UserProfile = {
      uid: `usr-${Date.now()}`,
      name,
      email,
      role: 'user',
      selectedInterests: [],
      createdAt: new Date().toISOString(),
    };
    setUser(newUser);
    return true;
  };

  const logout = async (): Promise<void> => {
    if (isFirebaseConfigured && auth) {
      try {
        await fbSignOut(auth);
      } catch (e) {
        console.warn(e);
      }
    }
    setUser(null);
  };

  const updateInterests = (interests: string[]) => {
    setUser((prev) => {
      if (!prev) return null;
      return {
        ...prev,
        selectedInterests: interests,
      };
    });
  };

  const switchRole = (role: UserRole) => {
    setUser((prev) => {
      if (!prev) return null;
      return {
        ...prev,
        role,
      };
    });
  };

  const loginAsAdmin = () => {
    setUser({
      uid: 'admin-root',
      name: 'System Administrator',
      email: 'admin@findmyitem.com',
      role: 'admin',
      selectedInterests: ['cat-mobile', 'cat-gaming', 'cat-audio'],
      createdAt: new Date().toISOString(),
    });
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        isAdmin: user?.role === 'admin',
        login,
        signup,
        logout,
        updateInterests,
        switchRole,
        loginAsAdmin,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used inside AuthProvider');
  return ctx;
}
