import React, { createContext, useContext, useState, useEffect } from 'react';
import { useAuth } from './AuthContext';
import { getStoredWishlist, saveStoredWishlist } from '../services/storageService';

interface WishlistContextValue {
  wishlistIds: string[];
  isInWishlist: (productId: string) => boolean;
  toggleWishlist: (productId: string) => void;
  removeFromWishlist: (productId: string) => void;
  clearWishlist: () => void;
  wishlistCount: number;
}

const WishlistContext = createContext<WishlistContextValue | undefined>(undefined);

export const WishlistProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user } = useAuth();
  const userId = user?.uid || 'guest';

  const [wishlistIds, setWishlistIds] = useState<string[]>(() => {
    return getStoredWishlist(userId);
  });

  useEffect(() => {
    setWishlistIds(getStoredWishlist(userId));
  }, [userId]);

  const toggleWishlist = (productId: string) => {
    setWishlistIds((prev) => {
      const exists = prev.includes(productId);
      const updated = exists ? prev.filter((id) => id !== productId) : [...prev, productId];
      saveStoredWishlist(userId, updated);
      return updated;
    });
  };

  const removeFromWishlist = (productId: string) => {
    setWishlistIds((prev) => {
      const updated = prev.filter((id) => id !== productId);
      saveStoredWishlist(userId, updated);
      return updated;
    });
  };

  const clearWishlist = () => {
    setWishlistIds([]);
    saveStoredWishlist(userId, []);
  };

  const isInWishlist = (productId: string) => wishlistIds.includes(productId);

  return (
    <WishlistContext.Provider
      value={{
        wishlistIds,
        isInWishlist,
        toggleWishlist,
        removeFromWishlist,
        clearWishlist,
        wishlistCount: wishlistIds.length,
      }}
    >
      {children}
    </WishlistContext.Provider>
  );
};

export function useWishlist(): WishlistContextValue {
  const ctx = useContext(WishlistContext);
  if (!ctx) throw new Error('useWishlist must be used inside WishlistProvider');
  return ctx;
}
