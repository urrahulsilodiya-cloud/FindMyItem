import React from 'react';
import {
  Shirt,
  Smartphone,
  Gamepad2,
  Footprints,
  Headphones,
  Dumbbell,
  Baby,
  Home,
  Tv,
  Apple,
  Sparkles,
  Dog,
  ShoppingBag,
  Layers,
  Watch,
  Coffee,
  Camera,
  Heart,
  Tag,
  Zap,
} from 'lucide-react';

export function getCategoryIcon(nameOrKey: string, className = 'w-6 h-6'): React.ReactNode {
  const normalized = (nameOrKey || '').toLowerCase();

  switch (normalized) {
    case 'fashion':
    case 'shirt':
    case 'apparel':
      return <Shirt className={className} />;
    case 'mobile':
    case 'smartphone':
    case 'phone':
      return <Smartphone className={className} />;
    case 'gaming':
    case 'gamepad2':
    case 'console':
      return <Gamepad2 className={className} />;
    case 'shoes':
    case 'footprints':
    case 'sneakers':
      return <Footprints className={className} />;
    case 'audio':
    case 'headphones':
    case 'sound':
      return <Headphones className={className} />;
    case 'fitness':
    case 'dumbbell':
    case 'gym':
      return <Dumbbell className={className} />;
    case 'kids':
    case 'baby':
    case 'toys':
      return <Baby className={className} />;
    case 'home':
    case 'household':
      return <Home className={className} />;
    case 'electronics':
    case 'tv':
    case 'tech':
      return <Tv className={className} />;
    case 'grocery':
    case 'apple':
    case 'food':
      return <Apple className={className} />;
    case 'beauty':
    case 'sparkles':
    case 'cosmetics':
      return <Sparkles className={className} />;
    case 'pets':
    case 'dog':
    case 'animals':
      return <Dog className={className} />;
    case 'watches':
      return <Watch className={className} />;
    case 'coffee':
      return <Coffee className={className} />;
    case 'camera':
      return <Camera className={className} />;
    default:
      return <Tag className={className} />;
  }
}
