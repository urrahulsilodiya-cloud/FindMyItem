import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, ExternalLink, ArrowRight } from 'lucide-react';
import { Product } from '../../types';

interface VideoModalProps {
  product: Product | null;
  onClose: () => void;
  onSelectProduct?: (product: Product) => void;
}

export const VideoModal: React.FC<VideoModalProps> = ({ product, onClose, onSelectProduct }) => {
  if (!product) return null;

  const videoId = product.youtubeVideoId;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/80 backdrop-blur-sm">
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          className="bg-white rounded-2xl shadow-2xl max-w-3xl w-full overflow-hidden border border-slate-200"
        >
          {/* Header */}
          <div className="p-4 sm:p-5 flex items-center justify-between border-b border-slate-100">
            <div className="pr-4">
              <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-red-50 text-red-600 mb-1">
                <span className="w-1.5 h-1.5 rounded-full bg-red-600 animate-pulse" />
                YouTube Product Review
              </span>
              <h3 className="font-bold text-slate-900 text-base sm:text-lg line-clamp-1">
                {product.youtubeTitle || `${product.brand} ${product.name} Video Review`}
              </h3>
            </div>
            <button
              onClick={onClose}
              className="p-2 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors shrink-0"
              aria-label="Close video modal"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Video Player */}
          <div className="relative aspect-video bg-black">
            {videoId ? (
              <iframe
                className="w-full h-full"
                src={`https://www.youtube-nocookie.com/embed/${videoId}?autoplay=1&rel=0`}
                title={product.youtubeTitle || product.name}
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
              />
            ) : (
              <div className="w-full h-full flex flex-col items-center justify-center text-slate-400 p-6 text-center">
                <p>No video player ID found for this product.</p>
                <a
                  href={product.youtubeUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="mt-3 text-blue-600 hover:underline inline-flex items-center gap-1 text-sm font-medium"
                >
                  Open on YouTube <ExternalLink className="w-4 h-4" />
                </a>
              </div>
            )}
          </div>

          {/* Description & CTAs */}
          <div className="p-4 sm:p-5 bg-slate-50 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="text-sm text-slate-600">
              <span className="font-semibold text-slate-800">{product.name}</span>
              {product.youtubeDescription && (
                <p className="text-xs text-slate-500 mt-1 line-clamp-2">{product.youtubeDescription}</p>
              )}
            </div>
            <div className="flex items-center gap-2.5 w-full sm:w-auto shrink-0">
              {onSelectProduct && (
                <button
                  onClick={() => {
                    onClose();
                    onSelectProduct(product);
                  }}
                  className="flex-1 sm:flex-none px-4 py-2 text-sm font-semibold text-slate-700 bg-white border border-slate-200 rounded-xl hover:bg-slate-100 transition-colors inline-flex items-center justify-center gap-1.5"
                >
                  View Details <ArrowRight className="w-4 h-4" />
                </button>
              )}
              <a
                href={product.buyUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex-1 sm:flex-none px-4 py-2 text-sm font-semibold text-white bg-blue-600 rounded-xl hover:bg-blue-700 transition-colors shadow-sm inline-flex items-center justify-center gap-1.5"
              >
                Buy on {product.sellerName} <ExternalLink className="w-4 h-4" />
              </a>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
