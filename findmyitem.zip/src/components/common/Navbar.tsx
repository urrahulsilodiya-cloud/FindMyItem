import React, { useState, useEffect, useRef } from 'react';
import {
  Search,
  Heart,
  User,
  ShieldCheck,
  Menu,
  X,
  Compass,
  Video,
  ChevronDown,
  Layers,
  Sparkles,
  ExternalLink,
  SlidersHorizontal,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useWishlist } from '../../context/WishlistContext';
import { useCurrency, CURRENCIES, CurrencyCode } from '../../context/CurrencyContext';
import { Category } from '../../types';
import { getActiveCategories } from '../../services/categoryService';
import { getCategoryIcon } from '../../utils/categoryIcons';

interface NavbarProps {
  currentRoute: string;
  onNavigate: (route: string, param?: string) => void;
  onOpenAuth: () => void;
  onSearchSubmit: (query: string) => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentRoute,
  onNavigate,
  onOpenAuth,
  onSearchSubmit,
  searchQuery,
  setSearchQuery,
}) => {
  const { user, isAdmin, switchRole, logout } = useAuth();
  const { wishlistCount } = useWishlist();
  const { currentCurrency, setCurrency } = useCurrency();

  const [categories, setCategories] = useState<Category[]>([]);
  const [categoriesOpen, setCategoriesOpen] = useState(false);
  const [currencyOpen, setCurrencyOpen] = useState(false);
  const [userMenuOpen, setUserMenuOpen] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const categoriesRef = useRef<HTMLDivElement>(null);
  const userMenuRef = useRef<HTMLDivElement>(null);
  const currencyRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    getActiveCategories().then(setCategories);
  }, []);

  // Close menus on outside click
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (categoriesRef.current && !categoriesRef.current.contains(e.target as Node)) {
        setCategoriesOpen(false);
      }
      if (userMenuRef.current && !userMenuRef.current.contains(e.target as Node)) {
        setUserMenuOpen(false);
      }
      if (currencyRef.current && !currencyRef.current.contains(e.target as Node)) {
        setCurrencyOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSearchKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && searchQuery.trim()) {
      onSearchSubmit(searchQuery);
    }
  };

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200/80 transition-all">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-20 gap-3 sm:gap-6">
          
          {/* Brand Logo */}
          <button
            onClick={() => onNavigate('home')}
            className="flex items-center gap-2.5 text-left group shrink-0 focus:outline-none"
            aria-label="FindMyItem Home"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-600 to-indigo-700 flex items-center justify-center text-white shadow-md shadow-blue-500/20 group-hover:scale-105 transition-transform">
              <Compass className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="flex items-center tracking-tight text-xl font-bold font-['Space_Grotesk'] text-slate-900">
                <span>Find</span>
                <span className="text-blue-600">My</span>
                <span>Item</span>
              </div>
              <span className="hidden sm:block text-[10px] uppercase font-semibold tracking-wider text-slate-400">
                Discover • Review • Decide
              </span>
            </div>
          </button>

          {/* Desktop Search Bar (Google styled clean pill) */}
          <div className="hidden md:flex flex-1 max-w-xl mx-2">
            <div className="relative w-full">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                <Search className="w-4 h-4" />
              </div>
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onKeyDown={handleSearchKeyPress}
                placeholder="Search products, brands, categories, tags..."
                className="w-full pl-10 pr-20 py-2.5 bg-slate-100/90 hover:bg-slate-100 focus:bg-white text-sm text-slate-900 placeholder-slate-500 rounded-full border border-transparent focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10 transition-all outline-none"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute inset-y-0 right-14 pr-2 flex items-center text-xs text-slate-400 hover:text-slate-600"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
              <button
                onClick={() => onSearchSubmit(searchQuery)}
                className="absolute inset-y-1 right-1 px-3 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-full transition-colors flex items-center"
              >
                Search
              </button>
            </div>
          </div>

          {/* Desktop Navigation Links */}
          <nav className="hidden lg:flex items-center gap-1 xl:gap-2">
            <button
              onClick={() => onNavigate('home')}
              className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-colors ${
                currentRoute === 'home'
                  ? 'text-blue-600 bg-blue-50/80 font-semibold'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              Home
            </button>

            {/* Categories dropdown */}
            <div className="relative" ref={categoriesRef}>
              <button
                onClick={() => setCategoriesOpen(!categoriesOpen)}
                className={`px-3 py-1.5 rounded-lg text-sm font-medium inline-flex items-center gap-1 transition-colors ${
                  categoriesOpen || currentRoute === 'category'
                    ? 'text-blue-600 bg-blue-50/80 font-semibold'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                }`}
              >
                Categories
                <ChevronDown className={`w-3.5 h-3.5 transition-transform ${categoriesOpen ? 'rotate-180' : ''}`} />
              </button>

              {categoriesOpen && (
                <div className="absolute top-full left-0 mt-2 w-72 bg-white rounded-2xl shadow-xl border border-slate-200/80 py-2.5 z-50 animate-in fade-in slide-in-from-top-2 duration-150">
                  <div className="px-3 py-1 text-xs font-semibold text-slate-400 uppercase tracking-wider">
                    Explore Interests
                  </div>
                  <div className="max-h-80 overflow-y-auto mt-1">
                    {categories.map((cat) => (
                      <button
                        key={cat.id}
                        onClick={() => {
                          setCategoriesOpen(false);
                          onNavigate('category', cat.slug);
                        }}
                        className="w-full px-3 py-2 text-left flex items-center gap-3 hover:bg-slate-50 transition-colors"
                      >
                        <div className="w-8 h-8 rounded-lg bg-slate-100 flex items-center justify-center text-slate-600 shrink-0">
                          {getCategoryIcon(cat.icon || cat.slug, 'w-4 h-4')}
                        </div>
                        <div>
                          <div className="text-sm font-medium text-slate-800">{cat.name}</div>
                          <div className="text-xs text-slate-400 line-clamp-1">{cat.description}</div>
                        </div>
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>

            <button
              onClick={() => onNavigate('reviews')}
              className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-colors ${
                currentRoute === 'reviews'
                  ? 'text-blue-600 bg-blue-50/80 font-semibold'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              Reviews
            </button>

            <button
              onClick={() => onNavigate('youtube')}
              className={`px-3 py-1.5 rounded-lg text-sm font-medium inline-flex items-center gap-1.5 transition-colors ${
                currentRoute === 'youtube'
                  ? 'text-red-600 bg-red-50 font-semibold'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <Video className="w-4 h-4 text-red-500" />
              YouTube
            </button>
          </nav>

          {/* Right actions: Currency, Wishlist, Account, Role */}
          <div className="flex items-center gap-1.5 sm:gap-2">
            
            {/* Currency switcher */}
            <div className="relative" ref={currencyRef}>
              <button
                onClick={() => setCurrencyOpen(!currencyOpen)}
                className="px-2.5 py-1.5 rounded-lg text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200/80 transition-colors inline-flex items-center gap-1"
                title="Select Currency"
              >
                <span>{CURRENCIES[currentCurrency].symbol} {currentCurrency}</span>
                <ChevronDown className="w-3 h-3 text-slate-500" />
              </button>

              {currencyOpen && (
                <div className="absolute right-0 top-full mt-2 w-44 bg-white rounded-xl shadow-xl border border-slate-200 py-1.5 z-50">
                  <div className="px-3 py-1 text-[11px] font-semibold text-slate-400 uppercase">Currency</div>
                  {(Object.keys(CURRENCIES) as CurrencyCode[]).map((code) => (
                    <button
                      key={code}
                      onClick={() => {
                        setCurrency(code);
                        setCurrencyOpen(false);
                      }}
                      className={`w-full px-3 py-1.5 text-left text-xs flex items-center justify-between hover:bg-slate-50 ${
                        currentCurrency === code ? 'text-blue-600 font-bold bg-blue-50/50' : 'text-slate-700'
                      }`}
                    >
                      <span>{CURRENCIES[code].name}</span>
                      <span className="font-mono text-slate-400">{CURRENCIES[code].symbol}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Wishlist Icon */}
            <button
              onClick={() => onNavigate('wishlist')}
              className="relative p-2 rounded-xl text-slate-600 hover:text-slate-900 hover:bg-slate-100 transition-colors"
              aria-label="View Wishlist"
              title="Saved Wishlist"
            >
              <Heart className={`w-5 h-5 ${wishlistCount > 0 ? 'fill-rose-500 text-rose-500' : ''}`} />
              {wishlistCount > 0 && (
                <span className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-rose-500 text-white text-[10px] font-bold flex items-center justify-center border-2 border-white shadow-sm">
                  {wishlistCount}
                </span>
              )}
            </button>

            {/* Account / User Menu */}
            <div className="relative" ref={userMenuRef}>
              <button
                onClick={() => setUserMenuOpen(!userMenuOpen)}
                className="flex items-center gap-2 p-1.5 sm:px-3 sm:py-1.5 rounded-xl border border-slate-200 hover:border-slate-300 bg-white hover:bg-slate-50 transition-colors shadow-2xs"
                aria-label="User profile and admin settings"
              >
                <div className="w-7 h-7 rounded-full bg-blue-100 text-blue-700 flex items-center justify-center font-bold text-xs">
                  {user ? user.name.charAt(0).toUpperCase() : <User className="w-4 h-4" />}
                </div>
                <div className="hidden sm:block text-left">
                  <div className="text-xs font-semibold text-slate-800 line-clamp-1">
                    {user ? user.name : 'Account'}
                  </div>
                  <div className="text-[10px] font-medium text-slate-400 flex items-center gap-1">
                    {isAdmin ? (
                      <span className="text-blue-600 font-semibold flex items-center gap-0.5">
                        <ShieldCheck className="w-3 h-3" /> Admin
                      </span>
                    ) : (
                      'Shopper'
                    )}
                  </div>
                </div>
                <ChevronDown className="w-3 h-3 text-slate-400 hidden sm:block" />
              </button>

              {userMenuOpen && (
                <div className="absolute right-0 top-full mt-2 w-64 bg-white rounded-2xl shadow-xl border border-slate-200 py-2.5 z-50">
                  {user ? (
                    <div className="px-4 py-2 border-b border-slate-100">
                      <div className="text-sm font-semibold text-slate-900">{user.name}</div>
                      <div className="text-xs text-slate-500 truncate">{user.email}</div>
                      <div className="mt-2 inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[11px] font-semibold bg-slate-100 text-slate-700">
                        Role: {user.role === 'admin' ? 'System Admin' : 'Registered Member'}
                      </div>
                    </div>
                  ) : (
                    <div className="px-4 py-2 border-b border-slate-100">
                      <div className="text-sm font-semibold text-slate-900">Guest User</div>
                      <button
                        onClick={() => {
                          setUserMenuOpen(false);
                          onOpenAuth();
                        }}
                        className="mt-2 w-full py-1.5 px-3 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors"
                      >
                        Sign In / Register
                      </button>
                    </div>
                  )}

                  <div className="p-1.5 space-y-1">
                    <button
                      onClick={() => {
                        setUserMenuOpen(false);
                        onNavigate('home', 'interests');
                      }}
                      className="w-full px-3 py-2 text-left text-xs font-medium text-slate-700 hover:bg-slate-100 rounded-lg flex items-center gap-2"
                    >
                      <Sparkles className="w-4 h-4 text-amber-500" />
                      Manage My Interests
                    </button>

                    <button
                      onClick={() => {
                        setUserMenuOpen(false);
                        onNavigate('wishlist');
                      }}
                      className="w-full px-3 py-2 text-left text-xs font-medium text-slate-700 hover:bg-slate-100 rounded-lg flex items-center gap-2"
                    >
                      <Heart className="w-4 h-4 text-rose-500" />
                      My Saved Items ({wishlistCount})
                    </button>

                    <div className="my-1 border-t border-slate-100" />

                    {/* Admin Switcher for smooth evaluation and real control */}
                    <div className="px-3 py-1.5">
                      <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-1">
                        Role Switcher
                      </div>
                      <div className="grid grid-cols-2 gap-1 p-0.5 bg-slate-100 rounded-lg">
                        <button
                          onClick={() => switchRole('user')}
                          className={`py-1 text-xs font-medium rounded-md transition-colors ${
                            !isAdmin ? 'bg-white shadow-2xs font-semibold text-slate-900' : 'text-slate-500'
                          }`}
                        >
                          User
                        </button>
                        <button
                          onClick={() => switchRole('admin')}
                          className={`py-1 text-xs font-medium rounded-md transition-colors ${
                            isAdmin ? 'bg-blue-600 text-white shadow-2xs font-semibold' : 'text-slate-500'
                          }`}
                        >
                          Admin
                        </button>
                      </div>
                    </div>

                    {isAdmin && (
                      <button
                        onClick={() => {
                          setUserMenuOpen(false);
                          onNavigate('admin');
                        }}
                        className="w-full px-3 py-2 text-left text-xs font-semibold text-blue-700 bg-blue-50/80 hover:bg-blue-100 rounded-lg flex items-center justify-between"
                      >
                        <span className="flex items-center gap-2">
                          <ShieldCheck className="w-4 h-4 text-blue-600" />
                          Admin Console
                        </span>
                        <span className="text-[10px] bg-blue-600 text-white px-1.5 py-0.5 rounded">CRUD</span>
                      </button>
                    )}

                    {user && (
                      <button
                        onClick={() => {
                          setUserMenuOpen(false);
                          logout();
                        }}
                        className="w-full px-3 py-2 text-left text-xs font-medium text-rose-600 hover:bg-rose-50 rounded-lg"
                      >
                        Sign Out
                      </button>
                    )}
                  </div>
                </div>
              )}
            </div>

            {/* Mobile Menu Hamburger */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 rounded-xl text-slate-600 hover:text-slate-900 hover:bg-slate-100 transition-colors"
              aria-label="Toggle Navigation Menu"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Mobile Search Bar (visible on small screens) */}
        <div className="md:hidden pb-3 pt-1">
          <div className="relative w-full">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
              <Search className="w-4 h-4" />
            </div>
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyDown={handleSearchKeyPress}
              placeholder="Search products, brands, categories..."
              className="w-full pl-9 pr-16 py-2 bg-slate-100 focus:bg-white text-xs text-slate-900 rounded-full border border-transparent focus:border-blue-500 focus:ring-2 focus:ring-blue-500/10 outline-none"
            />
            <button
              onClick={() => onSearchSubmit(searchQuery)}
              className="absolute inset-y-1 right-1 px-2.5 text-[11px] font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-full flex items-center"
            >
              Go
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-t border-slate-200 bg-white px-4 pt-3 pb-6 space-y-3">
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onNavigate('home');
              }}
              className="p-2.5 rounded-xl bg-slate-50 text-slate-800 text-xs font-semibold text-left"
            >
              Home
            </button>
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onNavigate('reviews');
              }}
              className="p-2.5 rounded-xl bg-slate-50 text-slate-800 text-xs font-semibold text-left"
            >
              Reviews
            </button>
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onNavigate('youtube');
              }}
              className="p-2.5 rounded-xl bg-red-50 text-red-700 text-xs font-semibold text-left flex items-center gap-1.5"
            >
              <Video className="w-4 h-4 text-red-600" />
              YouTube Hub
            </button>
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onNavigate('wishlist');
              }}
              className="p-2.5 rounded-xl bg-rose-50 text-rose-700 text-xs font-semibold text-left flex items-center gap-1.5"
            >
              <Heart className="w-4 h-4 text-rose-600" />
              Saved Items ({wishlistCount})
            </button>
          </div>

          {isAdmin && (
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onNavigate('admin');
              }}
              className="w-full p-2.5 rounded-xl bg-blue-600 text-white text-xs font-bold text-center flex items-center justify-center gap-2"
            >
              <ShieldCheck className="w-4 h-4" />
              Open Admin Dashboard
            </button>
          )}

          <div className="pt-2 border-t border-slate-100">
            <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">
              Browse Categories
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {categories.map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => {
                    setMobileMenuOpen(false);
                    onNavigate('category', cat.slug);
                  }}
                  className="p-2 rounded-lg bg-slate-50 hover:bg-slate-100 text-left flex items-center gap-2 text-xs font-medium text-slate-700"
                >
                  <div className="text-slate-500">{getCategoryIcon(cat.icon || cat.slug, 'w-3.5 h-3.5')}</div>
                  <span className="truncate">{cat.name}</span>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </header>
  );
};
