import React, { useState, useEffect } from 'react';
import { Compass, Video, Shield, ExternalLink, Heart, Globe2 } from 'lucide-react';
import { Category, SiteSettings } from '../../types';
import { getActiveCategories } from '../../services/categoryService';
import { getSettings } from '../../services/storageService';

interface FooterProps {
  onNavigate: (route: string, param?: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate }) => {
  const [categories, setCategories] = useState<Category[]>([]);
  const [settings, setSettings] = useState<SiteSettings | null>(null);

  useEffect(() => {
    getActiveCategories().then((cats) => setCategories(cats.slice(0, 8)));
    getSettings().then(setSettings);
  }, []);

  return (
    <footer className="bg-slate-900 text-slate-300 border-t border-slate-800 text-sm mt-20">
      {/* Top Value Banner */}
      <div className="border-b border-slate-800 py-8 bg-slate-900/60">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6 text-center md:text-left">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-blue-600/20 border border-blue-500/30 flex items-center justify-center text-blue-400">
                <Compass className="w-5 h-5" />
              </div>
              <div>
                <h4 className="font-semibold text-white text-base">
                  Find what you need. Understand it. Watch the review. Then decide.
                </h4>
                <p className="text-xs text-slate-400 mt-0.5">
                  Unbiased product discovery paired with verified video breakdown analysis.
                </p>
              </div>
            </div>
            <div className="flex items-center gap-4 text-xs font-medium text-slate-400">
              <span className="flex items-center gap-1.5">
                <Shield className="w-4 h-4 text-emerald-400" /> 100% Independent Reviews
              </span>
              <span className="flex items-center gap-1.5">
                <Video className="w-4 h-4 text-red-400" /> Embedded YouTube Tests
              </span>
              <span className="flex items-center gap-1.5">
                <Globe2 className="w-4 h-4 text-blue-400" /> Global Marketplaces
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Main Footer Links */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-8">
          
          {/* Col 1: Brand & Concept */}
          <div className="col-span-2 space-y-4">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center text-white font-bold text-sm">
                F
              </div>
              <span className="font-bold text-lg text-white font-['Space_Grotesk'] tracking-tight">
                Find<span className="text-blue-400">My</span>Item
              </span>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed max-w-sm">
              FindMyItem is a global product discovery and review platform. We do not directly sell or store products. We empower buyers to evaluate specifications, compare pros and cons, watch video reviews, and connect directly with trusted verified sellers.
            </p>
            <div className="text-xs text-slate-500">
              Support: <a href="mailto:support@findmyitem.com" className="text-blue-400 hover:underline">support@findmyitem.com</a>
            </div>
          </div>

          {/* Col 2: Categories */}
          <div>
            <h5 className="font-semibold text-white text-xs uppercase tracking-wider mb-3">Top Interests</h5>
            <ul className="space-y-2 text-xs">
              {categories.map((c) => (
                <li key={c.id}>
                  <button
                    onClick={() => onNavigate('category', c.slug)}
                    className="hover:text-white transition-colors"
                  >
                    {c.name}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Col 3: Discovery */}
          <div>
            <h5 className="font-semibold text-white text-xs uppercase tracking-wider mb-3">Discovery</h5>
            <ul className="space-y-2 text-xs">
              <li>
                <button onClick={() => onNavigate('home', 'interests')} className="hover:text-white transition-colors">
                  Choose Interests
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('reviews')} className="hover:text-white transition-colors">
                  Product Reviews
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('youtube')} className="hover:text-white transition-colors flex items-center gap-1">
                  <Video className="w-3 h-3 text-red-400" />
                  YouTube Showcase
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('wishlist')} className="hover:text-white transition-colors flex items-center gap-1">
                  <Heart className="w-3 h-3 text-rose-400" />
                  My Wishlist
                </button>
              </li>
            </ul>
          </div>

          {/* Col 4: Platform & Legal */}
          <div>
            <h5 className="font-semibold text-white text-xs uppercase tracking-wider mb-3">Platform</h5>
            <ul className="space-y-2 text-xs">
              <li>
                <span className="text-slate-400">About FindMyItem</span>
              </li>
              <li>
                <span className="text-slate-400">Review Methodology</span>
              </li>
              <li>
                <span className="text-slate-400">Verified Sellers</span>
              </li>
              <li>
                <span className="text-slate-400">Privacy Policy</span>
              </li>
              <li>
                <span className="text-slate-400">Terms of Service</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Required Seller & Legal Disclosure Section */}
        <div className="mt-10 pt-6 border-t border-slate-800 text-xs text-slate-500 leading-relaxed bg-slate-950/40 p-4 rounded-xl border border-slate-800/80">
          <div className="flex items-start gap-2.5">
            <Shield className="w-4 h-4 text-slate-400 shrink-0 mt-0.5" />
            <div>
              <span className="font-semibold text-slate-400 block mb-0.5">Affiliate & Marketplace Transparency Disclosure:</span>
              <p>
                {settings?.footerDisclosure ||
                  'FindMyItem helps you discover and research products. Product availability, pricing and purchase transactions are handled by the respective seller or marketplace. FindMyItem does not directly sell or store products.'}
              </p>
            </div>
          </div>
        </div>

        {/* Copyright */}
        <div className="mt-6 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 gap-3">
          <div>
            © {new Date().getFullYear()} FindMyItem Inc. All rights reserved. Designed for global product discovery.
          </div>
          <div className="flex items-center gap-4">
            <a href="https://youtube.com" target="_blank" rel="noreferrer" className="hover:text-slate-300">YouTube</a>
            <a href="https://twitter.com" target="_blank" rel="noreferrer" className="hover:text-slate-300">Twitter</a>
            <a href="https://github.com" target="_blank" rel="noreferrer" className="hover:text-slate-300">GitHub</a>
          </div>
        </div>
      </div>
    </footer>
  );
};
