import React, { useState, useEffect } from 'react';
import {
  Sparkles,
  TrendingUp,
  Flame,
  Clock,
  Video,
  ArrowRight,
  SlidersHorizontal,
  ChevronRight,
  ShieldCheck,
  CheckCircle2,
} from 'lucide-react';
import { Product, Category } from '../../types';
import {
  getRecommendedProducts,
  getTrendingInInterests,
  getLatestProducts,
  getPopularProducts,
  getProductsWithReviews,
} from '../../services/productService';
import { getActiveCategories } from '../../services/categoryService';
import { ProductCard } from '../product/ProductCard';
import { ProductGrid } from '../product/ProductGrid';
import { getCategoryIcon } from '../../utils/categoryIcons';

interface PersonalizedHomeProps {
  userInterests: string[];
  onChangeInterests: () => void;
  onSelectProduct: (product: Product) => void;
  onWatchVideo: (product: Product) => void;
  onNavigateCategory: (slug: string) => void;
  onNavigateReviews: () => void;
}

export const PersonalizedHome: React.FC<PersonalizedHomeProps> = ({
  userInterests,
  onChangeInterests,
  onSelectProduct,
  onWatchVideo,
  onNavigateCategory,
  onNavigateReviews,
}) => {
  const [categories, setCategories] = useState<Category[]>([]);
  const [recommended, setRecommended] = useState<Product[]>([]);
  const [trending, setTrending] = useState<Product[]>([]);
  const [latest, setLatest] = useState<Product[]>([]);
  const [popular, setPopular] = useState<Product[]>([]);
  const [reviewProducts, setReviewProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let mounted = true;
    async function loadData() {
      setLoading(true);
      const [cats, rec, trend, lat, pop, vid] = await Promise.all([
        getActiveCategories(),
        getRecommendedProducts(userInterests, 4),
        getTrendingInInterests(userInterests, 4),
        getLatestProducts(4),
        getPopularProducts(4),
        getProductsWithReviews(4),
      ]);
      if (mounted) {
        setCategories(cats);
        setRecommended(rec);
        setTrending(trend);
        setLatest(lat);
        setPopular(pop);
        setReviewProducts(vid);
        setLoading(false);
      }
    }
    loadData();
    return () => {
      mounted = false;
    };
  }, [userInterests]);

  const activeInterestCategories = categories.filter((c) => userInterests.includes(c.id));

  return (
    <div className="space-y-12 sm:space-y-16 py-6 sm:py-10">
      
      {/* Personalized Welcome Header Banner */}
      <div className="bg-gradient-to-r from-blue-900 via-indigo-900 to-slate-900 rounded-3xl p-6 sm:p-10 text-white relative overflow-hidden shadow-xl">
        <div className="absolute -right-16 -top-16 w-80 h-80 rounded-full bg-blue-500/20 blur-3xl pointer-events-none" />
        <div className="relative z-10 max-w-3xl">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-white/10 text-blue-200 backdrop-blur-md mb-4 border border-white/10">
            <Sparkles className="w-3.5 h-3.5 text-blue-300" />
            <span>Personalized Discovery Feed</span>
          </div>
          <h1 className="text-2xl sm:text-4xl font-extrabold tracking-tight font-['Space_Grotesk'] leading-tight">
            Curated products tailored to your chosen interests.
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 mt-2.5 max-w-xl leading-relaxed">
            Read unbiased deep-dives, view comprehensive specifications, watch verified YouTube hands-on reviews, and click through to trusted stores when you're ready.
          </p>

          {/* Interests Pill Row */}
          <div className="mt-6 flex flex-wrap items-center gap-2">
            <span className="text-xs text-blue-200 font-medium">Your Active Interests:</span>
            {activeInterestCategories.map((c) => (
              <button
                key={c.id}
                onClick={() => onNavigateCategory(c.slug)}
                className="px-3 py-1 rounded-full text-xs font-semibold bg-white/15 hover:bg-white/25 text-white backdrop-blur-xs transition-colors flex items-center gap-1.5"
              >
                <span>{c.name}</span>
                <ChevronRight className="w-3 h-3 text-blue-200" />
              </button>
            ))}
            <button
              onClick={onChangeInterests}
              className="px-3 py-1 rounded-full text-xs font-semibold bg-blue-500 hover:bg-blue-400 text-white transition-colors flex items-center gap-1 shadow-xs ml-1"
            >
              <SlidersHorizontal className="w-3 h-3" />
              <span>Change Interests</span>
            </button>
          </div>
        </div>
      </div>

      {/* SECTION 1: Recommended for You */}
      <section>
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-blue-100 text-blue-700 flex items-center justify-center">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-lg sm:text-xl font-bold text-slate-900 tracking-tight">
                Recommended for You
              </h2>
              <p className="text-xs text-slate-500">Selected based on your active interest categories</p>
            </div>
          </div>
          {activeInterestCategories[0] && (
            <button
              onClick={() => onNavigateCategory(activeInterestCategories[0].slug)}
              className="text-xs font-semibold text-blue-600 hover:text-blue-700 flex items-center gap-1"
            >
              View More <ArrowRight className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
        <ProductGrid
          products={recommended}
          isLoading={loading}
          onSelectProduct={onSelectProduct}
          onWatchVideo={onWatchVideo}
        />
      </section>

      {/* SECTION 2: Trending in Your Interests */}
      <section>
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-amber-100 text-amber-700 flex items-center justify-center">
              <TrendingUp className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-lg sm:text-xl font-bold text-slate-900 tracking-tight">
                Trending in Your Interests
              </h2>
              <p className="text-xs text-slate-500">High engagement and top-rated items right now</p>
            </div>
          </div>
        </div>
        <ProductGrid
          products={trending}
          isLoading={loading}
          onSelectProduct={onSelectProduct}
          onWatchVideo={onWatchVideo}
        />
      </section>

      {/* Category Quick Browse Bar */}
      <section className="bg-slate-100/80 rounded-2xl p-6 border border-slate-200/80">
        <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-4">
          Explore by Category
        </h3>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3">
          {categories.slice(0, 12).map((cat) => (
            <button
              key={cat.id}
              onClick={() => onNavigateCategory(cat.slug)}
              className="p-3 rounded-xl bg-white hover:bg-blue-50 border border-slate-200/80 hover:border-blue-200 text-left transition-all group flex items-center gap-2.5 shadow-2xs"
            >
              <div className="w-8 h-8 rounded-lg bg-slate-50 group-hover:bg-blue-600 group-hover:text-white text-slate-600 flex items-center justify-center transition-colors">
                {getCategoryIcon(cat.icon || cat.slug, 'w-4 h-4')}
              </div>
              <span className="text-xs font-semibold text-slate-800 group-hover:text-blue-700 truncate">
                {cat.name}
              </span>
            </button>
          ))}
        </div>
      </section>

      {/* SECTION 3: Watch Reviews (Dedicated YouTube Feature Section) */}
      <section className="bg-gradient-to-br from-red-50/50 via-slate-50 to-white rounded-3xl p-6 sm:p-8 border border-red-100/80 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-6">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-red-600 text-white flex items-center justify-center shadow-sm">
              <Video className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg sm:text-xl font-bold text-slate-900 tracking-tight">
                  Watch Reviews
                </h2>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-red-100 text-red-700">
                  YouTube Hub
                </span>
              </div>
              <p className="text-xs text-slate-500">In-depth video breakdowns before you decide</p>
            </div>
          </div>
          <button
            onClick={onNavigateReviews}
            className="text-xs font-semibold text-red-600 hover:text-red-700 flex items-center gap-1 self-start sm:self-auto"
          >
            Explore All Video Reviews <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {reviewProducts.map((p) => (
            <div
              key={p.id}
              className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-2xs hover:shadow-md transition-shadow flex flex-col justify-between"
            >
              <div
                className="relative aspect-video bg-slate-900 cursor-pointer group"
                onClick={() => onWatchVideo(p)}
              >
                <img
                  src={p.images[0]}
                  alt={p.name}
                  className="w-full h-full object-cover group-hover:opacity-85 transition-opacity"
                />
                <div className="absolute inset-0 flex items-center justify-center bg-black/30 group-hover:bg-black/40 transition-colors">
                  <div className="w-12 h-12 rounded-full bg-red-600 text-white flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform">
                    <Video className="w-5 h-5 fill-white text-white ml-0.5" />
                  </div>
                </div>
                <div className="absolute bottom-2 left-2 right-2 px-2 py-1 rounded bg-black/75 text-white text-[10px] font-medium line-clamp-1">
                  {p.youtubeTitle || `Hands-on Review: ${p.name}`}
                </div>
              </div>

              <div className="p-3.5 flex-1 flex flex-col justify-between">
                <div>
                  <span className="text-[10px] font-bold text-blue-600 uppercase tracking-wider">{p.brand}</span>
                  <h4
                    onClick={() => onSelectProduct(p)}
                    className="font-bold text-slate-900 text-xs hover:text-blue-600 cursor-pointer line-clamp-2 mt-0.5"
                  >
                    {p.name}
                  </h4>
                </div>
                <div className="mt-3 flex items-center justify-between gap-2">
                  <button
                    onClick={() => onWatchVideo(p)}
                    className="w-full py-1.5 px-2 rounded-lg text-xs font-semibold bg-red-50 hover:bg-red-100 text-red-700 transition-colors flex items-center justify-center gap-1.5"
                  >
                    <Video className="w-3.5 h-3.5" /> Watch Video
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* SECTION 4: Popular Products & Recently Added Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Popular */}
        <section className="bg-white rounded-3xl p-6 border border-slate-200/90 shadow-2xs">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Flame className="w-5 h-5 text-orange-500" />
              <h3 className="font-bold text-slate-900 text-base">Popular Products</h3>
            </div>
          </div>
          <div className="divide-y divide-slate-100">
            {popular.slice(0, 3).map((prod) => (
              <div
                key={prod.id}
                onClick={() => onSelectProduct(prod)}
                className="py-3 flex items-center gap-3 hover:bg-slate-50 -mx-2 px-2 rounded-xl cursor-pointer transition-colors"
              >
                <img
                  src={prod.images[0]}
                  alt={prod.name}
                  className="w-14 h-14 rounded-xl object-cover shrink-0 bg-slate-100"
                />
                <div className="flex-1 min-w-0">
                  <div className="text-[11px] font-semibold text-blue-600 uppercase">{prod.brand}</div>
                  <h4 className="text-xs font-bold text-slate-900 truncate">{prod.name}</h4>
                  <div className="text-xs font-bold text-slate-700 mt-0.5">${prod.price}</div>
                </div>
                <ChevronRight className="w-4 h-4 text-slate-400 shrink-0" />
              </div>
            ))}
          </div>
        </section>

        {/* Recently Added */}
        <section className="bg-white rounded-3xl p-6 border border-slate-200/90 shadow-2xs">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Clock className="w-5 h-5 text-indigo-500" />
              <h3 className="font-bold text-slate-900 text-base">Recently Added</h3>
            </div>
          </div>
          <div className="divide-y divide-slate-100">
            {latest.slice(0, 3).map((prod) => (
              <div
                key={prod.id}
                onClick={() => onSelectProduct(prod)}
                className="py-3 flex items-center gap-3 hover:bg-slate-50 -mx-2 px-2 rounded-xl cursor-pointer transition-colors"
              >
                <img
                  src={prod.images[0]}
                  alt={prod.name}
                  className="w-14 h-14 rounded-xl object-cover shrink-0 bg-slate-100"
                />
                <div className="flex-1 min-w-0">
                  <div className="text-[11px] font-semibold text-blue-600 uppercase">{prod.brand}</div>
                  <h4 className="text-xs font-bold text-slate-900 truncate">{prod.name}</h4>
                  <div className="text-xs font-bold text-slate-700 mt-0.5">${prod.price}</div>
                </div>
                <ChevronRight className="w-4 h-4 text-slate-400 shrink-0" />
              </div>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
};
