import React, { useState } from 'react';
import { TrendingUp, ArrowRight } from 'lucide-react';
import { Product, Category } from '../../types';
import { ProductCard } from '../product/ProductCard';

interface TrendingProductsProps {
  products: Product[];
  categories: Category[];
  onSelectProduct: (product: Product) => void;
  onWatchVideo: (product: Product) => void;
  onNavigateCategory: (slug: string) => void;
}

export const TrendingProducts: React.FC<TrendingProductsProps> = ({
  products,
  categories,
  onSelectProduct,
  onWatchVideo,
  onNavigateCategory,
}) => {
  const [selectedCategoryFilter, setSelectedCategoryFilter] = useState<string>('all');

  // Filter products by category if a pill is clicked
  const filteredProducts =
    selectedCategoryFilter === 'all'
      ? products
      : products.filter((p) => p.categoryId === selectedCategoryFilter);

  // Top 5 categories to show as quick pills
  const topFilterCategories = categories.slice(0, 6);

  return (
    <section className="space-y-6">
      {/* Section Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-slate-200/80 pb-4">
        <div>
          <div className="inline-flex items-center gap-1.5 text-xs font-semibold text-amber-700 bg-amber-50 px-2.5 py-0.5 rounded-full mb-1.5">
            <TrendingUp className="w-3.5 h-3.5 text-amber-600" />
            <span>High Engagement & Reviews</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight font-['Space_Grotesk']">
            Trending Products
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            Customer favorites and highest-rated gear explored across the community
          </p>
        </div>

        {/* Filter Pills */}
        <div className="flex flex-wrap items-center gap-1.5">
          <button
            onClick={() => setSelectedCategoryFilter('all')}
            className={`px-3 py-1.5 rounded-full text-xs font-semibold transition-colors ${
              selectedCategoryFilter === 'all'
                ? 'bg-slate-900 text-white shadow-xs'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            All Trending
          </button>
          {topFilterCategories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategoryFilter(cat.id)}
              className={`px-3 py-1.5 rounded-full text-xs font-semibold transition-colors ${
                selectedCategoryFilter === cat.id
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {cat.name}
            </button>
          ))}
        </div>
      </div>

      {/* Products Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        {filteredProducts.slice(0, 8).map((product) => (
          <ProductCard
            key={product.id}
            product={product}
            onSelect={onSelectProduct}
            onWatchVideo={onWatchVideo}
          />
        ))}
      </div>

      {filteredProducts.length === 0 && (
        <div className="py-12 text-center text-xs text-slate-500 bg-white rounded-2xl border border-slate-200">
          No trending products currently available for this category.
        </div>
      )}
    </section>
  );
};
