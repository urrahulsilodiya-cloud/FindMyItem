import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Check, Sparkles, ArrowRight, Layers, HelpCircle } from 'lucide-react';
import { Category, Subcategory } from '../../types';
import { getActiveCategories, getAllSubcategories } from '../../services/categoryService';
import { getCategoryIcon } from '../../utils/categoryIcons';

interface InterestPickerProps {
  initialSelected?: string[];
  onComplete: (selectedCategoryIds: string[]) => void;
  onSkip?: () => void;
}

export const InterestPicker: React.FC<InterestPickerProps> = ({
  initialSelected = [],
  onComplete,
  onSkip,
}) => {
  const [categories, setCategories] = useState<Category[]>([]);
  const [subcategories, setSubcategories] = useState<Subcategory[]>([]);
  const [selectedCats, setSelectedCats] = useState<string[]>(initialSelected);
  const [step, setStep] = useState<'categories' | 'subcategories'>('categories');
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    Promise.all([getActiveCategories(), getAllSubcategories()]).then(([cats, subs]) => {
      setCategories(cats);
      setSubcategories(subs);
      setIsLoading(false);
    });
  }, []);

  const toggleCategory = (catId: string) => {
    setSelectedCats((prev) =>
      prev.includes(catId) ? prev.filter((id) => id !== catId) : [...prev, catId]
    );
  };

  const handleContinue = () => {
    if (selectedCats.length === 0) return;
    // Check if any selected category has subcategories
    const hasSubs = subcategories.some((s) => selectedCats.includes(s.parentCategoryId));
    if (hasSubs && step === 'categories') {
      setStep('subcategories');
    } else {
      onComplete(selectedCats);
    }
  };

  const selectedCategoryObjects = categories.filter((c) => selectedCats.includes(c.id));
  const relevantSubcategories = subcategories.filter((s) => selectedCats.includes(s.parentCategoryId));

  return (
    <div className="max-w-5xl mx-auto px-4 py-8 sm:py-16">
      {/* Header section (strictly matching Section 2 specification) */}
      <div className="text-center max-w-2xl mx-auto mb-10">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-blue-50 text-blue-700 border border-blue-100 mb-4">
          <Sparkles className="w-3.5 h-3.5 text-blue-600" />
          <span>Curated Personal Discovery</span>
        </div>

        <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-slate-900 tracking-tight font-['Space_Grotesk']">
          What are you looking for today?
        </h1>

        <p className="text-sm sm:text-base text-slate-600 mt-3 leading-relaxed">
          Choose your interests and we'll show you products, reviews and useful information based on what you like.
        </p>

        {step === 'categories' ? (
          <div className="mt-4 flex items-center justify-center gap-2 text-xs font-medium text-slate-500">
            <span>Select 1 or more categories to personalize your feed</span>
            {selectedCats.length > 0 && (
              <span className="px-2 py-0.5 rounded-full bg-blue-600 text-white font-bold text-[11px]">
                {selectedCats.length} selected
              </span>
            )}
          </div>
        ) : (
          <div className="mt-4 flex items-center justify-center gap-2 text-xs font-medium text-slate-500">
            <span>Here are trending subcategories in your chosen interests</span>
          </div>
        )}
      </div>

      {/* Step 1: Category Card Grid */}
      {step === 'categories' && (
        <>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-4 mb-10">
            {categories.map((category) => {
              const isSelected = selectedCats.includes(category.id);
              return (
                <motion.div
                  key={category.id}
                  whileHover={{ y: -2 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => toggleCategory(category.id)}
                  className={`relative p-5 rounded-2xl border cursor-pointer select-none transition-all flex flex-col justify-between text-left group ${
                    isSelected
                      ? 'bg-blue-50/70 border-blue-500 shadow-md shadow-blue-500/10 ring-2 ring-blue-500/20'
                      : 'bg-white border-slate-200/90 hover:border-slate-300 hover:shadow-md hover:shadow-slate-100'
                  }`}
                >
                  {/* Selected checkmark indicator */}
                  <div
                    className={`absolute top-3.5 right-3.5 w-6 h-6 rounded-full flex items-center justify-center transition-all ${
                      isSelected
                        ? 'bg-blue-600 text-white scale-100'
                        : 'border border-slate-300 text-transparent opacity-0 group-hover:opacity-100'
                    }`}
                  >
                    <Check className="w-3.5 h-3.5 stroke-[3]" />
                  </div>

                  {/* Icon */}
                  <div
                    className={`w-12 h-12 rounded-xl flex items-center justify-center mb-3 transition-colors ${
                      isSelected
                        ? 'bg-blue-600 text-white shadow-sm'
                        : 'bg-slate-100 text-slate-700 group-hover:bg-blue-50 group-hover:text-blue-600'
                    }`}
                  >
                    {getCategoryIcon(category.icon || category.slug, 'w-6 h-6')}
                  </div>

                  {/* Text details */}
                  <div>
                    <h3 className="font-bold text-slate-900 text-base mb-1 group-hover:text-blue-600 transition-colors">
                      {category.name}
                    </h3>
                    <p className="text-xs text-slate-500 line-clamp-2 leading-relaxed">
                      {category.description}
                    </p>
                  </div>
                </motion.div>
              );
            })}
          </div>

          {/* Bottom Actions */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
            <button
              onClick={handleContinue}
              disabled={selectedCats.length === 0}
              className={`w-full sm:w-auto px-8 py-3.5 rounded-full text-sm font-bold flex items-center justify-center gap-2 transition-all shadow-md ${
                selectedCats.length > 0
                  ? 'bg-blue-600 hover:bg-blue-700 text-white shadow-blue-500/25 cursor-pointer scale-100'
                  : 'bg-slate-200 text-slate-400 cursor-not-allowed shadow-none'
              }`}
            >
              <span>Continue with {selectedCats.length || 'your'} {selectedCats.length === 1 ? 'interest' : 'interests'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            {onSkip && (
              <button
                onClick={onSkip}
                className="w-full sm:w-auto px-6 py-3 text-xs font-semibold text-slate-500 hover:text-slate-800 transition-colors"
              >
                Skip & Explore All Products
              </button>
            )}
          </div>
        </>
      )}

      {/* Step 2: Subcategories preview & personalization */}
      {step === 'subcategories' && (
        <div className="space-y-8 animate-in fade-in duration-200">
          <div className="p-4 rounded-xl bg-blue-50/60 border border-blue-100 flex items-center justify-between">
            <div className="flex items-center gap-2 text-xs text-blue-900 font-medium">
              <Layers className="w-4 h-4 text-blue-600" />
              <span>Selected Categories: {selectedCategoryObjects.map((c) => c.name).join(', ')}</span>
            </div>
            <button
              onClick={() => setStep('categories')}
              className="text-xs text-blue-700 font-semibold hover:underline"
            >
              Change
            </button>
          </div>

          <div className="space-y-6">
            {selectedCategoryObjects.map((category) => {
              const subs = subcategories.filter((s) => s.parentCategoryId === category.id);
              if (subs.length === 0) return null;
              return (
                <div key={category.id} className="bg-white rounded-2xl border border-slate-200 p-5">
                  <div className="flex items-center gap-2.5 mb-3.5">
                    <div className="w-8 h-8 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center">
                      {getCategoryIcon(category.icon || category.slug, 'w-4 h-4')}
                    </div>
                    <div>
                      <h4 className="font-bold text-slate-900 text-sm">{category.name}</h4>
                      <p className="text-xs text-slate-400">Popular subcategories you'll see in your feed</p>
                    </div>
                  </div>

                  <div className="flex flex-wrap gap-2">
                    {subs.map((sub) => (
                      <span
                        key={sub.id}
                        className="px-3 py-1.5 rounded-full text-xs font-medium bg-slate-100 text-slate-700 hover:bg-slate-200 transition-colors flex items-center gap-1.5"
                      >
                        <Check className="w-3 h-3 text-blue-600" />
                        {sub.name}
                      </span>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>

          <div className="flex items-center justify-center gap-3 pt-4">
            <button
              onClick={() => setStep('categories')}
              className="px-6 py-3 rounded-full text-xs font-semibold text-slate-600 hover:bg-slate-100 border border-slate-200"
            >
              Back to Categories
            </button>
            <button
              onClick={() => onComplete(selectedCats)}
              className="px-8 py-3.5 rounded-full text-sm font-bold bg-blue-600 hover:bg-blue-700 text-white shadow-md shadow-blue-500/25 flex items-center gap-2"
            >
              <span>Explore My Personalized Feed</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
