import React, { useState } from 'react';
import { Video, Sparkles, Clock, ArrowRight, Play, Star, ExternalLink } from 'lucide-react';
import { Product } from '../../types';
import { useCurrency } from '../../context/CurrencyContext';

interface DiscoverMoreProps {
  videoProducts: Product[];
  latestProducts: Product[];
  featuredProducts: Product[];
  onSelectProduct: (product: Product) => void;
  onWatchVideo: (product: Product) => void;
  onNavigateReviews: () => void;
}

export const DiscoverMore: React.FC<DiscoverMoreProps> = ({
  videoProducts,
  latestProducts,
  featuredProducts,
  onSelectProduct,
  onWatchVideo,
  onNavigateReviews,
}) => {
  const { formatPrice } = useCurrency();
  const [activeTab, setActiveTab] = useState<'video' | 'latest' | 'featured'>('video');

  return (
    <section className="bg-slate-100/70 rounded-3xl p-6 sm:p-10 border border-slate-200 space-y-6">
      {/* Header & Tabs */}
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 border-b border-slate-200/80 pb-5">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight font-['Space_Grotesk']">
            Discover More
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            Continue exploring authentic video breakdowns, newly added tech, and staff highlights
          </p>
        </div>

        {/* Tab Controls */}
        <div className="flex items-center gap-1.5 p-1 bg-white rounded-xl border border-slate-200 shadow-2xs self-start sm:self-auto">
          <button
            onClick={() => setActiveTab('video')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors ${
              activeTab === 'video'
                ? 'bg-red-50 text-red-700 shadow-2xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Video className="w-3.5 h-3.5 text-red-500" />
            <span>Video Reviews</span>
          </button>

          <button
            onClick={() => setActiveTab('latest')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors ${
              activeTab === 'latest'
                ? 'bg-blue-50 text-blue-700 shadow-2xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Clock className="w-3.5 h-3.5 text-blue-500" />
            <span>Newest Additions</span>
          </button>

          <button
            onClick={() => setActiveTab('featured')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors ${
              activeTab === 'featured'
                ? 'bg-amber-50 text-amber-800 shadow-2xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-500" />
            <span>Staff Highlights</span>
          </button>
        </div>
      </div>

      {/* Tab 1: Video Reviews Showcase (Distinct Media Layout) */}
      {activeTab === 'video' && (
        <div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {videoProducts.slice(0, 4).map((p) => (
              <div
                key={p.id}
                className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-2xs hover:shadow-md transition-all flex flex-col justify-between group"
              >
                {/* 16:9 Thumbnail with Play Button */}
                <div
                  onClick={() => onWatchVideo(p)}
                  className="relative aspect-video bg-slate-900 cursor-pointer overflow-hidden"
                >
                  <img
                    src={p.images[0]}
                    alt={p.name}
                    className="w-full h-full object-cover group-hover:scale-105 group-hover:opacity-85 transition-all duration-300"
                  />
                  <div className="absolute inset-0 bg-black/35 flex items-center justify-center group-hover:bg-black/45 transition-colors">
                    <div className="w-11 h-11 rounded-full bg-red-600 text-white flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform">
                      <Play className="w-4 h-4 fill-white text-white ml-0.5" />
                    </div>
                  </div>
                  <div className="absolute bottom-2 left-2 right-2 px-2 py-0.5 rounded bg-black/75 text-white text-[10px] font-medium line-clamp-1 backdrop-blur-xs">
                    {p.youtubeTitle || `Hands-on Review: ${p.name}`}
                  </div>
                </div>

                {/* Info & Quick Actions */}
                <div className="p-3.5 flex-1 flex flex-col justify-between">
                  <div>
                    <div className="flex items-center justify-between text-[11px] mb-1">
                      <span className="font-semibold text-blue-600 uppercase">{p.brand}</span>
                      <span className="font-bold text-slate-900">{formatPrice(p.price)}</span>
                    </div>
                    <h3
                      onClick={() => onSelectProduct(p)}
                      className="font-bold text-slate-900 text-xs hover:text-blue-600 cursor-pointer line-clamp-2 leading-snug"
                    >
                      {p.name}
                    </h3>
                  </div>

                  <div className="mt-3 pt-3 border-t border-slate-100 flex items-center gap-2">
                    <button
                      onClick={() => onWatchVideo(p)}
                      className="w-full py-1.5 px-2 text-xs font-semibold bg-red-50 hover:bg-red-100 text-red-700 rounded-lg transition-colors flex items-center justify-center gap-1 cursor-pointer"
                    >
                      <Video className="w-3.5 h-3.5" />
                      Watch Review
                    </button>
                    <button
                      onClick={() => onSelectProduct(p)}
                      className="py-1.5 px-2.5 text-xs font-semibold bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg transition-colors shrink-0"
                    >
                      Details
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-4 text-center">
            <button
              onClick={onNavigateReviews}
              className="inline-flex items-center gap-1.5 text-xs font-semibold text-red-600 hover:text-red-700"
            >
              <span>Explore all dedicated video reviews</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}

      {/* Tab 2: Newest Additions List Card */}
      {activeTab === 'latest' && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {latestProducts.slice(0, 4).map((p) => (
            <div
              key={p.id}
              onClick={() => onSelectProduct(p)}
              className="bg-white rounded-2xl border border-slate-200 p-3.5 flex items-center gap-3.5 hover:border-slate-300 hover:shadow-xs transition-all cursor-pointer group"
            >
              <img
                src={p.images[0]}
                alt={p.name}
                className="w-16 h-16 rounded-xl object-cover bg-slate-50 shrink-0"
              />
              <div className="flex-1 min-w-0">
                <span className="text-[10px] font-bold text-blue-600 uppercase tracking-wider block">
                  {p.brand}
                </span>
                <h3 className="text-xs font-bold text-slate-900 truncate group-hover:text-blue-600 transition-colors">
                  {p.name}
                </h3>
                <div className="mt-1 flex items-center justify-between">
                  <span className="text-xs font-extrabold text-slate-900">{formatPrice(p.price)}</span>
                  <span className="text-[10px] text-slate-400">via {p.sellerName}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Tab 3: Staff Highlights Showcase */}
      {activeTab === 'featured' && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {featuredProducts.slice(0, 3).map((p) => (
            <div
              key={p.id}
              className="bg-white rounded-2xl border border-slate-200 p-5 shadow-2xs hover:shadow-md transition-all flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-3">
                  <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-amber-100 text-amber-800">
                    Staff Pick
                  </span>
                  <div className="flex items-center gap-1 text-xs font-semibold text-slate-700">
                    <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-500" />
                    <span>{p.rating.toFixed(1)}</span>
                  </div>
                </div>

                <div
                  onClick={() => onSelectProduct(p)}
                  className="aspect-video w-full rounded-xl overflow-hidden bg-slate-50 mb-3 cursor-pointer"
                >
                  <img
                    src={p.images[0]}
                    alt={p.name}
                    className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
                  />
                </div>

                <h3
                  onClick={() => onSelectProduct(p)}
                  className="font-bold text-slate-900 text-sm hover:text-blue-600 cursor-pointer line-clamp-1"
                >
                  {p.name}
                </h3>
                <p className="text-xs text-slate-500 mt-1 line-clamp-2 leading-relaxed">
                  {p.shortDescription}
                </p>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between">
                <div className="text-sm font-extrabold text-slate-900">
                  {formatPrice(p.price)}
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => onSelectProduct(p)}
                    className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-100 hover:bg-slate-200 text-slate-800 transition-colors"
                  >
                    View Specs
                  </button>
                  <a
                    href={p.buyUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    onClick={(e) => e.stopPropagation()}
                    className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-blue-600 hover:bg-blue-700 text-white transition-colors flex items-center gap-1"
                  >
                    Buy <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </section>
  );
};
