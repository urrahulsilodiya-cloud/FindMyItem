import React from 'react';
import { ArrowRight, Star, Video, ExternalLink, ShieldCheck, Sparkles, Layers } from 'lucide-react';
import { Product } from '../../types';
import { useCurrency } from '../../context/CurrencyContext';

interface HeroBannerProps {
  featuredProduct?: Product | null;
  onSelectProduct: (product: Product) => void;
  onWatchVideo: (product: Product) => void;
  onExploreClick: () => void;
  onNavigateCategory: (slug: string) => void;
}

export const HeroBanner: React.FC<HeroBannerProps> = ({
  featuredProduct,
  onSelectProduct,
  onWatchVideo,
  onExploreClick,
  onNavigateCategory,
}) => {
  const { formatPrice } = useCurrency();

  return (
    <section className="relative overflow-hidden rounded-3xl bg-gradient-to-b from-slate-900 via-slate-900 to-slate-950 text-white shadow-xl border border-slate-800">
      {/* Subtle architectural ambient lights (strictly non-neon, clean indigo/blue) */}
      <div className="absolute -top-32 -left-32 w-96 h-96 rounded-full bg-blue-600/15 blur-3xl pointer-events-none" />
      <div className="absolute -bottom-32 -right-32 w-96 h-96 rounded-full bg-indigo-500/10 blur-3xl pointer-events-none" />

      <div className="relative z-10 px-6 py-12 sm:px-12 sm:py-16 lg:py-20 max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-center">
          
          {/* Left Column: Value Proposition & CTAs */}
          <div className="lg:col-span-7 space-y-6 text-left">
            {/* Subtle Platform Badge */}
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold bg-white/10 text-blue-200 border border-white/10 backdrop-blur-xs">
              <Sparkles className="w-3.5 h-3.5 text-blue-400" />
              <span>Independent Product Discovery</span>
            </div>

            {/* Headline */}
            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight font-['Space_Grotesk'] text-white leading-tight">
              Discover Quality Products. <br className="hidden sm:inline" />
              <span className="text-blue-400">Tested, Reviewed & Curated.</span>
            </h1>

            {/* Supporting Sentence */}
            <p className="text-sm sm:text-base text-slate-300 max-w-xl leading-relaxed">
              Explore in-depth specifications, honest video reviews, and compare before shopping across trusted marketplaces.
            </p>

            {/* Action Buttons */}
            <div className="flex flex-wrap items-center gap-3 pt-2">
              <button
                onClick={onExploreClick}
                className="px-6 py-3.5 rounded-xl text-sm font-bold text-white bg-blue-600 hover:bg-blue-500 transition-all shadow-md shadow-blue-600/25 flex items-center gap-2 group cursor-pointer"
              >
                <span>Explore Products</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
              </button>

              <button
                onClick={() => onNavigateCategory('audio')}
                className="px-5 py-3.5 rounded-xl text-sm font-semibold text-slate-200 hover:text-white bg-white/10 hover:bg-white/15 border border-white/10 transition-all backdrop-blur-xs cursor-pointer"
              >
                Shop by Category
              </button>
            </div>

            {/* Trust Indicators */}
            <div className="pt-4 border-t border-slate-800/80 flex flex-wrap items-center gap-y-2 gap-x-6 text-xs text-slate-400">
              <span className="flex items-center gap-1.5 font-medium">
                <ShieldCheck className="w-4 h-4 text-blue-400" />
                Unbiased Specifications
              </span>
              <span className="flex items-center gap-1.5 font-medium">
                <Video className="w-4 h-4 text-red-400" />
                Hands-On YouTube Tests
              </span>
              <span className="flex items-center gap-1.5 font-medium">
                <ExternalLink className="w-3.5 h-3.5 text-emerald-400" />
                Authorized Retailers
              </span>
            </div>
          </div>

          {/* Right Column: Featured Product Presentation */}
          {featuredProduct && (
            <div className="lg:col-span-5">
              <div className="relative bg-slate-800/80 rounded-2xl p-5 border border-slate-700/80 shadow-2xl backdrop-blur-xs group">
                {/* Featured Badge */}
                <div className="absolute top-4 left-4 z-10 flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-bold bg-blue-600 text-white shadow-xs">
                  <Sparkles className="w-3 h-3" />
                  <span>Featured Product</span>
                </div>

                {/* Product Image Frame */}
                <div
                  onClick={() => onSelectProduct(featuredProduct)}
                  className="relative aspect-4/3 w-full rounded-xl overflow-hidden bg-slate-900 cursor-pointer"
                >
                  <img
                    src={featuredProduct.images[0]}
                    alt={featuredProduct.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-60" />
                </div>

                {/* Product Information */}
                <div className="mt-4 space-y-2 text-left">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-semibold text-blue-400 uppercase tracking-wider text-[11px]">
                      {featuredProduct.brand}
                    </span>
                    <div className="flex items-center gap-1 text-amber-300 font-medium bg-amber-400/10 px-2 py-0.5 rounded text-[11px]">
                      <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
                      <span>{featuredProduct.rating.toFixed(1)}</span>
                      <span className="text-slate-400">({featuredProduct.reviewCount})</span>
                    </div>
                  </div>

                  <h3
                    onClick={() => onSelectProduct(featuredProduct)}
                    className="text-base font-bold text-white hover:text-blue-300 cursor-pointer line-clamp-1 transition-colors"
                  >
                    {featuredProduct.name}
                  </h3>

                  <p className="text-xs text-slate-300 line-clamp-2 leading-relaxed">
                    {featuredProduct.shortDescription}
                  </p>

                  <div className="pt-3 border-t border-slate-700/60 flex items-center justify-between">
                    <div>
                      <div className="text-lg font-extrabold text-white">
                        {formatPrice(featuredProduct.price)}
                      </div>
                      <div className="text-[10px] text-slate-400">
                        Available on <span className="text-slate-200 font-medium">{featuredProduct.sellerName}</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      {featuredProduct.youtubeVideoId && (
                        <button
                          onClick={() => onWatchVideo(featuredProduct)}
                          className="px-3 py-2 rounded-xl text-xs font-semibold bg-red-600/90 hover:bg-red-600 text-white flex items-center gap-1.5 transition-colors shadow-xs"
                          title="Watch YouTube Review"
                        >
                          <Video className="w-3.5 h-3.5" />
                          <span className="hidden sm:inline">Watch Review</span>
                        </button>
                      )}

                      <button
                        onClick={() => onSelectProduct(featuredProduct)}
                        className="px-4 py-2 rounded-xl text-xs font-semibold bg-white text-slate-900 hover:bg-slate-100 transition-colors"
                      >
                        View Details
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

        </div>
      </div>
    </section>
  );
};
