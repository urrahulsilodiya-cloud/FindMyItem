import React from 'react';
import { ArrowRight, ChevronRight } from 'lucide-react';
import { Category } from '../../types';
import { getCategoryIcon } from '../../utils/categoryIcons';

interface ShopByCategoryProps {
  categories: Category[];
  onNavigateCategory: (slug: string) => void;
}

export const ShopByCategory: React.FC<ShopByCategoryProps> = ({
  categories,
  onNavigateCategory,
}) => {
  return (
    <section className="space-y-6">
      {/* Section Header */}
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-2 border-b border-slate-200/80 pb-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight font-['Space_Grotesk']">
            Shop by Category
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Browse our curated catalog across major consumer interest departments
          </p>
        </div>
      </div>

      {/* Categories Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3 sm:gap-4">
        {categories.map((cat) => (
          <button
            key={cat.id}
            onClick={() => onNavigateCategory(cat.slug)}
            className="group relative p-4 rounded-2xl bg-white hover:bg-slate-50/80 border border-slate-200/90 hover:border-blue-400/80 shadow-2xs hover:shadow-md transition-all duration-200 text-left flex flex-col justify-between cursor-pointer overflow-hidden"
          >
            {/* Top Icon with subtle accent background */}
            <div className="flex items-center justify-between mb-3">
              <div
                className="w-10 h-10 rounded-xl flex items-center justify-center transition-colors text-slate-700 group-hover:text-white"
                style={{
                  backgroundColor: `${cat.accentColor || '#3b82f6'}15`,
                }}
              >
                <div
                  className="transition-transform group-hover:scale-110"
                  style={{ color: cat.accentColor || '#3b82f6' }}
                >
                  {getCategoryIcon(cat.icon || cat.slug, 'w-5 h-5')}
                </div>
              </div>

              <ChevronRight className="w-4 h-4 text-slate-300 group-hover:text-blue-600 group-hover:translate-x-0.5 transition-all" />
            </div>

            {/* Category Name & Short Description */}
            <div>
              <h3 className="font-bold text-slate-900 text-sm group-hover:text-blue-600 transition-colors">
                {cat.name}
              </h3>
              <p className="text-[11px] text-slate-500 line-clamp-1 mt-0.5 leading-snug">
                {cat.description || `Discover ${cat.name} products`}
              </p>
            </div>
          </button>
        ))}
      </div>
    </section>
  );
};
