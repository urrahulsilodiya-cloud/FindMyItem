import React from 'react';
import { Compass, ShieldCheck, Video, ExternalLink, Info } from 'lucide-react';

export const TrustSection: React.FC = () => {
  return (
    <section className="bg-white rounded-3xl p-6 sm:p-10 border border-slate-200/90 shadow-2xs space-y-8">
      {/* Title & Concept */}
      <div className="text-center max-w-2xl mx-auto">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-slate-100 text-slate-700 mb-2">
          <Compass className="w-3.5 h-3.5 text-blue-600" />
          <span>About FindMyItem</span>
        </div>
        <h2 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight font-['Space_Grotesk']">
          Discover Products Based on Your Interests
        </h2>
        <p className="text-xs sm:text-sm text-slate-500 mt-2 leading-relaxed">
          FindMyItem is an independent product discovery and research platform. We help you explore curated items, understand detailed technical specifications, watch genuine video reviews, and shop directly at authorized marketplaces.
        </p>
      </div>

      {/* 3 Value Pillars */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-2">
        <div className="p-5 rounded-2xl bg-slate-50/80 border border-slate-200/80 flex flex-col items-start space-y-2.5">
          <div className="w-10 h-10 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <h3 className="font-bold text-slate-900 text-sm">
            1. Unbiased Discovery
          </h3>
          <p className="text-xs text-slate-600 leading-relaxed">
            We do not sell or store warehouse inventory. Every product is curated for quality, features, and honest consumer utility.
          </p>
        </div>

        <div className="p-5 rounded-2xl bg-slate-50/80 border border-slate-200/80 flex flex-col items-start space-y-2.5">
          <div className="w-10 h-10 rounded-xl bg-red-100 text-red-700 flex items-center justify-center">
            <Video className="w-5 h-5" />
          </div>
          <h3 className="font-bold text-slate-900 text-sm">
            2. Video & In-Depth Specs
          </h3>
          <p className="text-xs text-slate-600 leading-relaxed">
            Watch hands-on YouTube teardowns and performance reviews before you buy, alongside verified hardware and material specifications.
          </p>
        </div>

        <div className="p-5 rounded-2xl bg-slate-50/80 border border-slate-200/80 flex flex-col items-start space-y-2.5">
          <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center">
            <ExternalLink className="w-5 h-5" />
          </div>
          <h3 className="font-bold text-slate-900 text-sm">
            3. Trusted Seller Links
          </h3>
          <p className="text-xs text-slate-600 leading-relaxed">
            Once you decide, navigate directly to authorized retailers like Amazon, Best Buy, and verified brands for secure checkout.
          </p>
        </div>
      </div>

      {/* Unobtrusive Transparent Affiliate Disclosure */}
      <div className="pt-4 border-t border-slate-100 flex items-start sm:items-center gap-2.5 text-xs text-slate-400 bg-slate-50/50 p-3 rounded-xl">
        <Info className="w-4 h-4 text-slate-400 shrink-0 mt-0.5 sm:mt-0" />
        <p className="text-[11px] leading-relaxed">
          <strong className="font-semibold text-slate-600">Affiliate Disclosure:</strong> FindMyItem is a reader-supported discovery platform. When you click links and purchase products from external retailers, we may earn an affiliate commission at zero additional cost to you.
        </p>
      </div>
    </section>
  );
};
