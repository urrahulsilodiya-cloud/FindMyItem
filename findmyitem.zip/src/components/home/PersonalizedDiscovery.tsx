import React, { useState, useEffect } from 'react';
import { Sparkles, Check, ChevronRight, ArrowRight, SlidersHorizontal, RefreshCw } from 'lucide-react';
import { Category, Product } from '../../types';
import { getRecommendedProducts } from '../../services/productService';
import { getCategoryIcon } from '../../utils/categoryIcons';
import { ProductCard } from '../product/ProductCard';

interface PersonalizedDiscoveryProps {
  categories: Category[];
  userInterests: string[];
  onToggleInterest: (categoryId: string) => void;
  onSelectAllInterests: () => void;
  onClearInterests: () => void;
  onNavigateCategory: (slug: string) => void;
  onSelectProduct: (product: Product) => void;
  onWatchVideo: (product: Product) => void;
}

export const PersonalizedDiscovery: React.FC<PersonalizedDiscoveryProps> = ({
  categories,
  userInterests,
  onToggleInterest,
  onSelectAllInterests,
  onClearInterests,
  onNavigateCategory,
  onSelectProduct,
  onWatchVideo,
}) => {
  const [recommendedProducts, setRecommendedProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let mounted = true;
    setLoading(true);
    getRecommendedProducts(userInterests, 8).then((prods) => {
      if (mounted) {
        setRecommendedProducts(prods);
        setLoading(false);
      }
    });
    return () => {
      mounted = false;
    };
  }, [userInterests]);

  const activeInterestsCount = userInterests.length;

  return (
    <section id="personalized-discovery" className="space-y-8">
      {/* Section Header with exact requested text */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-2xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-100 pb-6">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-blue-50 text-blue-700 border border-blue-100 mb-2">
              <Sparkles className="w-3.5 h-3.5 text-blue-600" />
              <span>Personalized For You</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight font-['Space_Grotesk']">
              Find Products You'll Love
            </h2>
            <p className="text-sm text-slate-600 mt-1">
              Choose what you're interested in and discover products made for your interests.
            </p>
          </div>

          {/* Quick Filter Utilities */}
          <div className="flex items-center gap-2 self-start md:self-auto">
            <span className="text-xs text-slate-500 font-medium">
              {activeInterestsCount === 0
                ? 'Showing all categories'
                : `${activeInterestsCount} selected`}
            </span>
            {activeInterestsCount > 0 ? (
              <button
                onClick={onClearInterests}
                className="px-3 py-1.5 rounded-xl text-xs font-semibold text-slate-600 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 transition-colors"
              >
                Clear
              </button>
            ) : (
              <button
                onClick={onSelectAllInterests}
                className="px-3 py-1.5 rounded-xl text-xs font-semibold text-blue-600 hover:text-blue-700 bg-blue-50 hover:bg-blue-100 transition-colors"
              >
                Select All
              </button>
            )}
          </div>
        </div>

        {/* User Flow Step 1: Choose Interest Cards */}
        <div className="mt-6">
          <div className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-3 flex items-center justify-between">
            <span>Step 1: Choose Your Interests</span>
            <span className="text-[11px] lowercase text-slate-400">click to toggle • or click arrow to browse full category</span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-2.5">
            {categories.map((cat) => {
              const isSelected = userInterests.includes(cat.id);
              return (
                <div
                  key={cat.id}
                  onClick={() => onToggleInterest(cat.id)}
                  className={`relative p-3 rounded-xl border transition-all cursor-pointer select-none flex flex-col justify-between ${
                    isSelected
                      ? 'bg-blue-50/80 border-blue-500 shadow-xs ring-1 ring-blue-500/20'
                      : 'bg-slate-50/60 border-slate-200 hover:border-slate-300 hover:bg-slate-100/80'
                  }`}
                >
                  <div className="flex items-center justify-between gap-1">
                    <div
                      className={`w-7 h-7 rounded-lg flex items-center justify-center text-xs transition-colors ${
                        isSelected
                          ? 'bg-blue-600 text-white'
                          : 'bg-white text-slate-600 border border-slate-200'
                      }`}
                    >
                      {getCategoryIcon(cat.icon || cat.slug, 'w-3.5 h-3.5')}
                    </div>

                    <div className="flex items-center gap-1">
                      {isSelected ? (
                        <span className="w-5 h-5 rounded-full bg-blue-600 text-white flex items-center justify-center">
                          <Check className="w-3 h-3 stroke-[3]" />
                        </span>
                      ) : null}
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onNavigateCategory(cat.slug);
                        }}
                        className="p-1 text-slate-400 hover:text-blue-600 rounded-md hover:bg-white/80 transition-colors"
                        title={`Browse full ${cat.name} category`}
                        aria-label={`Browse ${cat.name} category`}
                      >
                        <ChevronRight className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  <div className="mt-2">
                    <div className="text-xs font-bold text-slate-900 truncate">
                      {cat.name}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* User Flow Step 2 & 3: Discover Products Matching Chosen Interests */}
        <div className="mt-10 pt-8 border-t border-slate-100">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h3 className="text-lg font-bold text-slate-900">
                Recommended Discoveries
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                {activeInterestsCount > 0
                  ? 'Showing handpicked products matching your chosen interest categories'
                  : 'Showing top curated discoveries across all departments'}
              </p>
            </div>

            {activeInterestsCount === 1 && (
              <button
                onClick={() => {
                  const activeCat = categories.find((c) => userInterests.includes(c.id));
                  if (activeCat) onNavigateCategory(activeCat.slug);
                }}
                className="text-xs font-semibold text-blue-600 hover:text-blue-700 flex items-center gap-1 cursor-pointer"
              >
                Browse Full Category <ArrowRight className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Product Grid */}
          {loading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
              {Array.from({ length: 4 }).map((_, i) => (
                <div key={i} className="bg-slate-50 rounded-2xl p-4 border border-slate-200 animate-pulse h-80" />
              ))}
            </div>
          ) : recommendedProducts.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
              {recommendedProducts.map((product) => (
                <ProductCard
                  key={product.id}
                  product={product}
                  onSelect={onSelectProduct}
                  onWatchVideo={onWatchVideo}
                />
              ))}
            </div>
          ) : (
            <div className="p-8 text-center text-slate-500 text-xs bg-slate-50 rounded-2xl">
              No products found for the selected interests. Try selecting other categories.
            </div>
          )}
        </div>
      </div>
    </section>
  );
};
