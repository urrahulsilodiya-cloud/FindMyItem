import React from 'react';
import { Product } from '../../types';
import { ProductCard } from './ProductCard';
import { PackageX } from 'lucide-react';

interface ProductGridProps {
  products: Product[];
  isLoading?: boolean;
  onSelectProduct: (product: Product) => void;
  onWatchVideo?: (product: Product) => void;
  emptyTitle?: string;
  emptyMessage?: string;
}

export const ProductGrid: React.FC<ProductGridProps> = ({
  products,
  isLoading = false,
  onSelectProduct,
  onWatchVideo,
  emptyTitle = 'No products found',
  emptyMessage = 'Try adjusting your filters, searching for a different keyword, or explore other categories.',
}) => {
  if (isLoading) {
    return (
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
        {Array.from({ length: 8 }).map((_, i) => (
          <div
            key={i}
            className="bg-white rounded-2xl border border-slate-200 p-4 space-y-3 animate-pulse"
          >
            <div className="aspect-square bg-slate-100 rounded-xl" />
            <div className="h-4 bg-slate-200 rounded w-1/3" />
            <div className="h-5 bg-slate-200 rounded w-4/5" />
            <div className="h-4 bg-slate-100 rounded w-full" />
            <div className="h-8 bg-slate-100 rounded w-full mt-4" />
          </div>
        ))}
      </div>
    );
  }

  if (products.length === 0) {
    return (
      <div className="bg-white rounded-2xl border border-slate-200/80 p-12 text-center max-w-lg mx-auto my-8 shadow-xs">
        <div className="w-14 h-14 rounded-2xl bg-slate-100 text-slate-400 flex items-center justify-center mx-auto mb-4">
          <PackageX className="w-7 h-7" />
        </div>
        <h3 className="font-bold text-slate-800 text-lg mb-1">{emptyTitle}</h3>
        <p className="text-xs text-slate-500 leading-relaxed">{emptyMessage}</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
      {products.map((product) => (
        <ProductCard
          key={product.id}
          product={product}
          onSelect={onSelectProduct}
          onWatchVideo={onWatchVideo}
        />
      ))}
    </div>
  );
};
