import React from 'react';
import { motion } from 'motion/react';
import { Star, Video, ExternalLink, Heart, ArrowRight } from 'lucide-react';
import { Product } from '../../types';
import { useWishlist } from '../../context/WishlistContext';
import { useCurrency } from '../../context/CurrencyContext';

interface ProductCardProps {
  product: Product;
  onSelect: (product: Product) => void;
  onWatchVideo?: (product: Product) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product, onSelect, onWatchVideo }) => {
  const { isInWishlist, toggleWishlist } = useWishlist();
  const { formatPrice } = useCurrency();
  const isSaved = isInWishlist(product.id);

  const hasVideo = Boolean(product.youtubeVideoId || product.youtubeUrl);

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ y: -3 }}
      transition={{ duration: 0.2 }}
      className="group bg-white rounded-2xl border border-slate-200/90 hover:border-slate-300 hover:shadow-lg hover:shadow-slate-200/50 flex flex-col justify-between overflow-hidden transition-all duration-200"
    >
      {/* Top Image & Badges */}
      <div className="relative aspect-square w-full bg-slate-100 overflow-hidden">
        <img
          src={product.images[0] || 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=600&q=80'}
          alt={product.name}
          loading="lazy"
          className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-300"
        />

        {/* Wishlist Button */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            toggleWishlist(product.id);
          }}
          className={`absolute top-2.5 right-2.5 p-2 rounded-full backdrop-blur-md transition-all shadow-sm ${
            isSaved
              ? 'bg-rose-50 text-rose-600'
              : 'bg-white/90 text-slate-500 hover:text-rose-500 hover:bg-white'
          }`}
          aria-label={isSaved ? 'Remove from wishlist' : 'Save to wishlist'}
        >
          <motion.div whileTap={{ scale: 0.8 }}>
            <Heart className={`w-4 h-4 ${isSaved ? 'fill-rose-500 text-rose-500' : ''}`} />
          </motion.div>
        </button>

        {/* Badges container */}
        <div className="absolute top-2.5 left-2.5 flex flex-col gap-1 items-start">
          {product.discount && product.discount > 0 ? (
            <span className="px-2 py-0.5 rounded-full text-[11px] font-bold bg-rose-600 text-white shadow-xs">
              {product.discount}% OFF
            </span>
          ) : null}
          {product.featured && (
            <span className="px-2 py-0.5 rounded-full text-[11px] font-bold bg-amber-500 text-white shadow-xs">
              Featured
            </span>
          )}
        </div>

        {/* YouTube Review Overlay Pill */}
        {hasVideo && (
          <button
            onClick={(e) => {
              e.stopPropagation();
              onWatchVideo?.(product);
            }}
            className="absolute bottom-2.5 left-2.5 px-2.5 py-1 rounded-full bg-slate-900/85 hover:bg-red-600 text-white text-[11px] font-semibold backdrop-blur-xs flex items-center gap-1.5 shadow-sm transition-colors"
          >
            <Video className="w-3.5 h-3.5 text-red-400 group-hover:text-white" />
            <span>Watch Review</span>
          </button>
        )}
      </div>

      {/* Product Content Details */}
      <div className="p-4 flex-1 flex flex-col justify-between">
        <div>
          {/* Brand & Rating */}
          <div className="flex items-center justify-between gap-2 text-xs mb-1.5">
            <span className="font-semibold text-blue-600 uppercase tracking-wider text-[11px]">
              {product.brand}
            </span>
            {product.rating > 0 && (
              <div className="flex items-center gap-1 text-slate-700 bg-amber-50 px-2 py-0.5 rounded-md font-medium text-[11px]">
                <Star className="w-3 h-3 fill-amber-400 text-amber-500" />
                <span>{product.rating.toFixed(1)}</span>
                <span className="text-slate-400 text-[10px]">({product.reviewCount})</span>
              </div>
            )}
          </div>

          {/* Title */}
          <h3
            onClick={() => onSelect(product)}
            className="font-bold text-slate-900 text-sm hover:text-blue-600 cursor-pointer line-clamp-2 leading-snug transition-colors"
            title={product.name}
          >
            {product.name}
          </h3>

          {/* Short description */}
          <p className="text-xs text-slate-500 mt-1 line-clamp-2 leading-relaxed">
            {product.shortDescription}
          </p>
        </div>

        {/* Pricing & External Seller */}
        <div className="mt-3 pt-3 border-t border-slate-100">
          <div className="flex items-baseline justify-between gap-2 mb-3">
            <div className="flex items-baseline gap-2">
              <span className="text-base font-extrabold text-slate-900">
                {formatPrice(product.price)}
              </span>
              {product.originalPrice && product.originalPrice > product.price && (
                <span className="text-xs text-slate-400 line-through">
                  {formatPrice(product.originalPrice)}
                </span>
              )}
            </div>
            <span className="text-[11px] font-medium text-slate-400">
              via <span className="text-slate-600 font-semibold">{product.sellerName}</span>
            </span>
          </div>

          {/* Action Buttons: View Details, Watch Review (if video exists), Buy Product */}
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={() => onSelect(product)}
              className="w-full py-2 px-3 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors flex items-center justify-center gap-1"
            >
              View Details
            </button>
            <a
              href={product.buyUrl}
              target="_blank"
              rel="noopener noreferrer"
              onClick={(e) => e.stopPropagation()}
              className="w-full py-2 px-3 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-xl transition-colors flex items-center justify-center gap-1 shadow-2xs"
            >
              Buy Product
              <ExternalLink className="w-3 h-3" />
            </a>
          </div>
        </div>
      </div>
    </motion.div>
  );
};
