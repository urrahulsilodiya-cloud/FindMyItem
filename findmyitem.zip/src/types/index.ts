export type UserRole = 'user' | 'admin';

export interface UserProfile {
  uid: string;
  name: string;
  email: string;
  role: UserRole;
  selectedInterests?: string[]; // category IDs or slugs
  createdAt?: string;
  avatarUrl?: string;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  icon: string; // Lucide icon name or emoji
  description: string;
  displayOrder: number;
  isActive: boolean;
  itemCount?: number;
  accentColor?: string;
}

export interface Subcategory {
  id: string;
  name: string;
  slug: string;
  parentCategoryId: string;
  icon?: string;
  description?: string;
  displayOrder: number;
  isActive: boolean;
}

export interface ProductSpecification {
  label: string;
  value: string;
}

export interface Product {
  id: string;
  name: string;
  slug: string;
  brand: string;
  categoryId: string;
  subcategoryId: string;
  price: number;
  originalPrice?: number;
  discount?: number; // percentage
  currency: string;
  images: string[];
  shortDescription: string;
  description: string;
  specifications: ProductSpecification[];
  howToUse?: string;
  pros: string[];
  cons: string[];
  rating: number; // e.g. 4.8
  reviewCount: number; // e.g. 1420
  youtubeVideoId?: string; // YouTube video ID (e.g., dQw4w9WgXcQ)
  youtubeUrl?: string;
  youtubeTitle?: string;
  youtubeDescription?: string;
  sellerName: string; // e.g., Amazon, Best Buy, Apple, B&H
  sellerLogo?: string;
  buyUrl: string; // External URL
  tags: string[];
  featured: boolean;
  published: boolean;
  inStock?: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface YouTubeReviewItem {
  id: string;
  productId: string;
  productName: string;
  brand: string;
  category: string;
  youtubeVideoId: string;
  youtubeTitle: string;
  youtubeUrl: string;
  reviewerName?: string;
  duration?: string;
  summary?: string;
  productSlug: string;
  thumbnailUrl: string;
}

export interface SiteSettings {
  websiteName: string;
  logoText: string;
  tagline: string;
  websiteDescription: string;
  defaultCurrency: string;
  contactEmail: string;
  footerDisclosure: string;
  socialLinks: {
    youtube?: string;
    twitter?: string;
    github?: string;
    instagram?: string;
  };
}

export interface FilterState {
  searchQuery?: string;
  categorySlug?: string;
  subcategorySlug?: string;
  minPrice?: number;
  maxPrice?: number;
  brands: string[];
  minRating?: number;
  sortBy: 'popular' | 'latest' | 'price-asc' | 'price-desc' | 'rating';
  hasVideoReview?: boolean;
}
